# SPDX-FileCopyrightText: Copyright (c) 2025 - 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# Use of this software is governed by the terms and conditions of the
# NVIDIA End User License Agreement (EULA), available at:
# https://docs.nvidia.com/cutlass/latest/media/docs/pythonDSL/license.html
#
# Any use, reproduction, disclosure, or distribution of this software
# and related documentation outside the scope permitted by the EULA
# is strictly prohibited.

"""
This module provides MLIR Dialect helper functions
"""

from . import nanobind_compat  # must be first: patches ir.Block, ir.InsertionPoint
from . import arith
from . import vector
from .lru_cache_ir import lru_cache_ir
from .op import dsl_user_op

__all__ = ["arith", "vector", "lru_cache_ir", "dsl_user_op"]

try:
    from . import gpu

    __all__.extend(["gpu"])
except ImportError:
    pass

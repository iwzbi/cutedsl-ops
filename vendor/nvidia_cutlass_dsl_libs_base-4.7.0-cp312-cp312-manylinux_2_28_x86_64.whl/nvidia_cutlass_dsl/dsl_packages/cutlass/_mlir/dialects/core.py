# SPDX-FileCopyrightText: Copyright (c) 2025 - 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

from ._core_ops_gen import *
from ._core_enum_gen import *

from ..ir import register_attribute_builder, Attribute


@register_attribute_builder("Core_OperationTypeEnumAttr")
def _core_operation_type_enum_attr(x, context):
    return Attribute.parse(f"#core.operation_type<value = {str(x)}>", context=context)

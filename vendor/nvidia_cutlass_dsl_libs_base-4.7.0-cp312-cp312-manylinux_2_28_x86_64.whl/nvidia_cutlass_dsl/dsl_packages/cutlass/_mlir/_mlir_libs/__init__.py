
from typing import Any, Mapping, Sequence

import os

_this_dir = os.path.dirname(__file__)

def get_lib_dirs() -> Sequence[str]:
    """Gets the lib directory for linking to shared libraries.

    On some platforms, the package may need to be built specially to export
    development libraries.
    """
    return [_this_dir]

def get_include_dirs() -> Sequence[str]:
    """Gets the include directory for compiling against exported C libraries.

    Depending on how the package was build, development C libraries may or may
    not be present.
    """
    return [os.path.join(_this_dir, "include")]

_dialect_registry = None
_load_on_create_dialects = None

def get_dialect_registry():
    global _dialect_registry

    if _dialect_registry is None:
        from ._cutlass_ir._mlir import ir

        _dialect_registry = ir.DialectRegistry()

    return _dialect_registry

def append_load_on_create_dialect(dialect: str):
    global _load_on_create_dialects
    if _load_on_create_dialects is None:
        _load_on_create_dialects = [dialect]
    else:
        _load_on_create_dialects.append(dialect)

def get_load_on_create_dialects():
    global _load_on_create_dialects
    if _load_on_create_dialects is None:
        _load_on_create_dialects = []
    return _load_on_create_dialects

def _select_and_load_cutlass_ir_toolkit():
    """Pick a toolkit-flavored _cutlass_ir.so (cu{N} sibling of this file)
    and bind it as the submodule. Runtime libs come from
    <nvidia_cutlass_dsl>/cu{N}/lib/ (wheel) or $LD_LIBRARY_PATH (editable)."""
    import ctypes
    import importlib.util
    import os
    import re
    import sys
    from pathlib import Path

    _LEGACY_NAME = "cutlass._mlir._mlir_libs._cutlass_ir"

    # Idempotent: if the module is already in sys.modules, nothing to do.
    if _LEGACY_NAME in sys.modules:
        return

    # Use the unresolved parent so that an editable / symlinked install (where
    # _mlir_libs/__init__.py is a symlink into the LLVM-prebuilt source tree)
    # still scans the dir Python imported from — where the CTK-tagged .so
    # siblings actually live — rather than the symlink target.
    this_dir = Path(__file__).parent

    flavor_re = re.compile(r"^_cutlass_ir\.cu(\d+)\.cpython-.*\.so$")
    # Walk up to <nvidia_cutlass_dsl>/ so we can locate each flavor's
    # runtime-library sibling at <nvidia_cutlass_dsl>/cu{N}/lib/. Walk by
    # name so wheel + editable installs (different parent-chain depths)
    # resolve identically.
    nvidia_root = None
    for parent in this_dir.parents:
        if parent.name == "nvidia_cutlass_dsl":
            nvidia_root = parent
            break

    # available[ctk] -> (so_path, runtime_lib_dir_or_None)
    available = {}
    for entry in this_dir.iterdir():
        m = flavor_re.match(entry.name)
        if not m:
            continue
        toolkit_ver = int(m.group(1))
        runtime_dir = None
        if nvidia_root is not None:
            runtime_lib = nvidia_root / f"cu{toolkit_ver}" / "lib" / "libcute_dsl_runtime.so"
            if runtime_lib.exists():
                runtime_dir = runtime_lib.parent
            elif (nvidia_root / f"cu{toolkit_ver}" / "lib").exists():
                # cu{N}/lib/ exists but the runtime library is missing —
                # incomplete install. Fail loudly rather than silently
                # falling through to the other flavor.
                raise RuntimeError(
                    f"cu{toolkit_ver} install is incomplete: "
                    f"{entry} present but {runtime_lib} is missing. "
                    f"Reinstall the cu{toolkit_ver} flavor."
                )
            # No cu{N}/ at all → editable install; runtime resolves via
            # $LD_LIBRARY_PATH or build-tree RPATH.
        available[toolkit_ver] = (entry, runtime_dir)

    if not available:
        raise RuntimeError(
            "No CTK flavor installed: expected one or more of "
            f"{this_dir}/_cutlass_ir.cu{{N}}.cpython-...so . "
            "Try `pip install nvidia-cutlass-dsl` (cu12 default) or "
            "`pip install 'nvidia-cutlass-dsl[cu13]'`."
        )

    # Probe driver. Failure is non-fatal (CPU-only / no-GPU containers).
    driver_cuda_int = None
    try:
        libcuda = ctypes.CDLL("libcuda.so.1")
        version = ctypes.c_int(0)
        if libcuda.cuDriverGetVersion(ctypes.byref(version)) == 0:
            driver_cuda_int = version.value
    except (OSError, AttributeError):
        driver_cuda_int = None

    if driver_cuda_int is not None:
        # cuDriverGetVersion returns an int like 12090 = "CUDA 12.9", 13010 = "CUDA 13.1".
        # Driver supports cuX if the reported runtime major >= X.
        driver_major = driver_cuda_int // 1000
        compatible = sorted(
            (toolkit_ver for toolkit_ver in available if driver_major >= toolkit_ver), reverse=True
        )
        if not compatible:
            installed = ", ".join(f"cu{c}" for c in sorted(available))
            driver_str = f"{driver_major}.{(driver_cuda_int % 1000) // 10}"
            raise RuntimeError(
                f"None of the installed toolkit flavors ({installed}) are compatible "
                f"with the CUDA driver (driver supports up to CUDA {driver_str}). "
                "Install a compatible flavor (e.g. `pip install nvidia-cutlass-dsl` "
                "for cu12) or update the driver."
            )
    else:
        # Driver-absent fallback: pick newest installed.
        compatible = sorted(available.keys(), reverse=True)

    chosen_toolkit_ver = compatible[0]
    chosen_so, chosen_runtime_dir = available[chosen_toolkit_ver]

    spec = importlib.util.spec_from_file_location(_LEGACY_NAME, str(chosen_so))
    if spec is None or spec.loader is None:
        raise RuntimeError(
            f"Failed to build import spec for the cu{chosen_toolkit_ver} pybind module at {chosen_so}"
        )
    module = importlib.util.module_from_spec(spec)
    sys.modules[_LEGACY_NAME] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        sys.modules.pop(_LEGACY_NAME, None)
        raise

    # Bind as an attribute of the parent package so attribute-style access
    # (e.g. getattr(cutlass._mlir._mlir_libs, "_cutlass_ir"), which the DSL
    # preprocessor's exec_imports relies on for `from cutlass._mlir._mlir_libs
    # import _cutlass_ir`) resolves. Python's import statement sets this when
    # loading a submodule, but our manual spec_from_file_location +
    # exec_module path bypasses that step.
    parent_pkg = sys.modules.get(__name__)
    if parent_pkg is not None:
        parent_pkg._cutlass_ir = module

    # Wire CUTE_DSL_LIBS so downstream `ctypes.CDLL("libcute_dsl_runtime.so")`
    # and the auto-discovery resolve to the chosen flavor's runtime.
    if chosen_runtime_dir is not None:
        runtime_so = chosen_runtime_dir / "libcute_dsl_runtime.so"
        if runtime_so.exists():
            sep = ";" if sys.platform.startswith("win32") else ":"
            existing = os.environ.get("CUTE_DSL_LIBS", "")
            existing_entries = existing.split(sep) if existing else []
            if str(runtime_so) not in existing_entries:
                # Prepend so the chosen flavor wins over any older value.
                os.environ["CUTE_DSL_LIBS"] = (
                    str(runtime_so) + (sep + existing if existing else "")
                )


# Module-level: load the toolkit-flavored _cutlass_ir into sys.modules BEFORE any
# subsequent code (including get_dialect_registry() and _site_initialize())
# tries `from ._cutlass_ir._mlir import ir`. Without this, Python's normal
# import machinery cannot resolve `_cutlass_ir` because the file is named
# `_cutlass_ir.cu{N}.cpython-…so` (a stem the standard finder skips).
_select_and_load_cutlass_ir_toolkit()


def _site_initialize():
    import importlib
    import itertools
    import logging
    from ._cutlass_ir._mlir import ir

    logger = logging.getLogger(__name__)
    post_init_hooks = []
    disable_multithreading = False

    disable_load_all_available_dialects = False

    def process_initializer_module(module_name):
        nonlocal disable_multithreading
        nonlocal disable_load_all_available_dialects
        try:
            m = importlib.import_module(f".{module_name}", __name__)
        except ModuleNotFoundError:
            return False
        except ImportError:
            message = (
                f"Error importing mlir initializer {module_name}. This may "
                "happen in unclean incremental builds but is likely a real bug if "
                "encountered otherwise and the MLIR Python API may not function."
            )
            logger.warning(message, exc_info=True)
            return False

        logger.debug("Initializing MLIR with module: %s", module_name)
        if hasattr(m, "register_dialects"):
            logger.debug("Registering dialects from initializer %r", m)
            m.register_dialects(get_dialect_registry())
        if hasattr(m, "context_init_hook"):
            logger.debug("Adding context init hook from %r", m)
            post_init_hooks.append(m.context_init_hook)
        if hasattr(m, "disable_multithreading"):
            if bool(m.disable_multithreading):
                logger.debug("Disabling multi-threading for context")
                disable_multithreading = True
        if hasattr(m, "disable_load_all_available_dialects"):
            disable_load_all_available_dialects = True
        return True

    init_module = None
    if process_initializer_module("_mlirRegisterEverything"):
        init_module = importlib.import_module(f"._mlirRegisterEverything", __name__)

    if not process_initializer_module("_cutlass_ir"):
        raise RuntimeError("Could not successfully initialize _cutlass_ir module.")

    ir._Context = ir.Context

    class Context(ir._Context):
        def __init__(
            self, load_on_create_dialects=None, thread_pool=None, *args, **kwargs
        ):
            super().__init__(*args, **kwargs)
            self.append_dialect_registry(get_dialect_registry())
            for hook in post_init_hooks:
                hook(self)
            if disable_multithreading and thread_pool is not None:
                raise ValueError(
                    "Context constructor has given thread_pool argument, "
                    "but disable_multithreading flag is True. "
                    "Please, set thread_pool argument to None or "
                    "set disable_multithreading flag to False."
                )
            if not disable_multithreading:
                if thread_pool is None:
                    self.enable_multithreading(True)
                else:
                    self.set_thread_pool(thread_pool)
            if load_on_create_dialects is not None:
                logger.debug(
                    "Loading all dialects from load_on_create_dialects arg %r",
                    load_on_create_dialects,
                )
                for dialect in load_on_create_dialects:

                    _ = self.dialects[dialect]
            else:
                if disable_load_all_available_dialects:
                    dialects = get_load_on_create_dialects()
                    if dialects:
                        logger.debug(
                            "Loading all dialects from global load_on_create_dialects %r",
                            dialects,
                        )
                        for dialect in dialects:

                            _ = self.dialects[dialect]
                else:
                    logger.debug("Loading all available dialects")
                    self.load_all_available_dialects()
            if init_module:
                logger.debug(
                    "Registering translations from initializer %r", init_module
                )
                init_module.register_llvm_translations(self)

    ir.Context = Context

    class MLIRError(Exception):
        """
        An exception with diagnostic information. Has the following fields:
          message: str
          error_diagnostics: List[ir.DiagnosticInfo]
        """

        def __init__(self, message, error_diagnostics):
            self.message = message
            self.error_diagnostics = error_diagnostics
            super().__init__(message, error_diagnostics)

        def __str__(self):
            s = self.message
            if self.error_diagnostics:
                s += ":"
            for diag in self.error_diagnostics:
                s += (
                    "\nerror: "
                    + str(diag.location)[4:-1]
                    + ": "
                    + diag.message.replace("\n", "\n  ")
                )
                for note in diag.notes:
                    s += (
                        "\n note: "
                        + str(note.location)[4:-1]
                        + ": "
                        + note.message.replace("\n", "\n  ")
                    )
            return s

    ir.MLIRError = MLIRError

    Sequence.register(ir.BlockArgumentList)
    Sequence.register(ir.BlockList)
    Sequence.register(ir.BlockSuccessors)
    Sequence.register(ir.BlockPredecessors)
    Sequence.register(ir.OperationList)
    Sequence.register(ir.OpOperandList)
    Sequence.register(ir.OpResultList)
    Sequence.register(ir.OpSuccessors)
    Sequence.register(ir.RegionSequence)
    Mapping.register(ir.OpAttributeMap)

_site_initialize()
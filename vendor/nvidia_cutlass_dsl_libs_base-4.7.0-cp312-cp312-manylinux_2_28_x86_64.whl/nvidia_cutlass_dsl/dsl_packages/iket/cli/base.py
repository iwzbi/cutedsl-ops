import os
import re
import argparse
import time
import shutil

from typing import List, Dict, Optional, Callable
from pathlib import Path
from subprocess import run, PIPE, STDOUT, Popen, CompletedProcess

from ..profiler import default_injection_lib
from .common import parse_arg, InjectionConfig
from ..utils import iket_print
from .._build_config import EXTERNAL_RELEASE



def configure_base(parser: argparse.ArgumentParser):
    default_log_level = "error" if EXTERNAL_RELEASE else "warn"
    parser.add_argument(
        "--use-injection-lib",
        type=str,
        help="use given injection lib instead of the bundled one",
    )
    parser.add_argument(
        "--skip-run", action="store_true", help="skip real run for underlying tool"
    )

    parser.add_argument(
        "--context-buffer-size",
        type=str,
        default=None,
        help="size of extra device buffer allocated per context. "
        "Default: auto-computed from tracker data, fallback 1G.",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        choices=["error", "warn", "info", "debug", "trace"],
        default=default_log_level,
        help=f"default: {default_log_level}",
    )

    parser.add_argument("--working-dir", type=str)
    parser.add_argument("--output-dir", "-o", type=str)
    parser.add_argument(
        "--clobber", action="store_true", help="clobber existing output directory"
    )


def default(val: object, default: object):
    if val is not None:
        return val
    else:
        return default


class SModelRunResult:
    def __init__(self, returncode: int, outputs: List[str]):
        self.returncode = returncode
        self.outputs = outputs


class SModelRun:
    def __init__(
        self,
        cmd: list[str],
        skip_run: bool,
        clobber: bool,
        context_buffer_size: int,
        log_level: str,
        working_dir: Optional[Path] = None,
        base_output_dir: Optional[Path] = None,
        injection_lib: Optional[Path] = None,
    ):
        self.cmd = cmd

        self.skip_run = skip_run
        self.clobber = clobber
        self.context_buffer_size = context_buffer_size
        self.log_level = log_level

        if not working_dir:
            self.working_dir = Path(os.getcwd()).absolute()
        else:
            self.working_dir = working_dir.absolute()

        if not base_output_dir:
            self._output_dir = self.working_dir
        else:
            self._output_dir = base_output_dir.absolute()

        self._injection_lib = injection_lib

        if self._output_dir.exists():
            if self.clobber:
                iket_print(f"Removing existing output directory: {self._output_dir}")
                shutil.rmtree(self._output_dir)
            else:
                user_input = (
                    input(
                        f"[run-iket] Output directory {self._output_dir} already exists. Remove it? [y/N]: "
                    )
                    .strip()
                    .lower()
                )
                if user_input == "y":
                    iket_print(
                        f"Removing existing output directory: {self._output_dir}"
                    )
                    shutil.rmtree(self._output_dir)
                else:
                    iket_print(
                        f"Output directory {self._output_dir} already exists. Exit now. Please use --clobber to overwrite or confirm removal."
                    )
                    exit(1)
        os.makedirs(self._output_dir, exist_ok=True)

    def get_output_dir(self, job: str = ""):
        if job:
            return self._output_dir / job
        else:
            return self._output_dir

    def get_injection_config_name(self, job: str = ""):
        if job:
            return f"{job}.config.json"
        else:
            return "config.json"

    @property
    def injection_lib_path(self):
        if self._injection_lib is None:
            return default_injection_lib
        else:
            return self._injection_lib

    def launch_gpu_workload(
        self,
        tool: str,
        tool_config: dict,
        env: Dict[str, str] = {},
        force_run: bool = False,
        job: str = "",
        extra_env: Dict[str, str] = {},
    ):
        """
        Launch a GPU workload.

        args:
            tool: the name of the tool, could be tracker, iket
            tool_config: the config of the tool
            env: the environment variables
        """
        if not env:
            env = os.environ.copy()

        job_output_dir = self.get_output_dir(job)
        if not job_output_dir.exists():
            job_output_dir.mkdir()

        injection_config_path = job_output_dir / self.get_injection_config_name(job)

        if tool:
            injection_config = InjectionConfig(
                self.context_buffer_size,
                job_output_dir,
                tool,
                tool_config,
                self.log_level,
            )
            injection_config.save(injection_config_path)

            injection_envs: Dict[str, str] = {
                "CUDA_INJECTION64_PATH": self.injection_lib_path,
                "SMODEL_INJECTION_CONFIG": f"{injection_config_path}",
            }
        else:
            # dry run
            injection_envs = {}


        # CuTe DSL strips iket ops at JIT compile time by default. Append "iket"
        # to CUTE_DSL_COMPILER_OPT so iket ops survive into LLVM lowering and the
        # injection tool can patch them, while preserving any other options the
        # user already set. CuTe DSL accepts comma- or space-separated tokens
        # with an optional "--" prefix; we match any of those for the existence
        # check and append using a comma.
        cute_dsl_envs: Dict[str, str] = {}
        existing_cute_opt = env.get("CUTE_DSL_COMPILER_OPT", "")
        has_iket = re.search(r"(?:^|[\s,])(?:--)?iket(?=$|[\s,{=])", existing_cute_opt)
        if not has_iket:
            cute_dsl_envs["CUTE_DSL_COMPILER_OPT"] = (
                f"{existing_cute_opt},iket" if existing_cute_opt else "iket"
            )

        user_command = " ".join(self.cmd)
        rerun_script_path = job_output_dir / "rerun.sh"
        with open(rerun_script_path, "w") as f:
            for k, v in cute_dsl_envs.items():
                f.write(f"export {k}={v}\n")

            # always set debug mode in rerun.sh
            if tool:
                f.write(f"export SMODEL_DEBUG_BREAK=1\n")
                for k, v in injection_envs.items():
                    f.write(f"export {k}={v}\n")
            elif extra_env:
                for k, v in extra_env.items():
                    f.write(f"export {k}={v}\n")

            f.write("# Working dir \n")
            f.write(f"cd {self.working_dir}\n")
            f.write("# Execute cmd\n")
            f.write(user_command + "\n")
            f.flush()

        env.update(cute_dsl_envs)
        env.update(injection_envs)
        env.update(extra_env)

        outputs: List[str] = []
        returncode: int = None

        if force_run or not self.skip_run:
            proc = Popen(
                self.cmd, stdout=PIPE, stderr=STDOUT, env=env, cwd=self.working_dir
            )

            while True:
                stdout_lines = proc.stdout.readlines()
                if not stdout_lines:
                    returncode = proc.poll()
                    if returncode is not None:
                        break

                for line_bytes in stdout_lines:
                    line = line_bytes.decode().rstrip("\n")
                    print(
                        line
                    )  # use print instead of iket_print to avoid unnecessary prefix
                    outputs.append(line)

                time.sleep(0.1)

            result = SModelRunResult(returncode, outputs)

            if result.returncode != 0:
                iket_print(
                    f"Launch GPU workload exits abnormally with return code: {result.returncode} => Tool: {tool}, Job: {job}"
                )
                iket_print(
                    f'Please run "{rerun_script_path.absolute()}" to reproduce the issue!'
                )
        else:
            iket_print(f"Skip execute user command for job: {job} => \n{user_command}")

            result = SModelRunResult(returncode, outputs)

        return result

    @staticmethod
    def create(
        known: argparse.Namespace, unknown: list[str], *, require_cmd: bool = True
    ) -> "SModelRun":
        """
        parse the arguments and create the SModelRun instance.

        args:
            known: the known arguments
            unknown: the unknown arguments
            require_cmd: whether to require the command

        return the SModelRun instance
        """
        if require_cmd and not unknown:
            RuntimeError(f"Missing command")
        elif unknown:
            # FORCE our users to add '--'
            if unknown[0] != "--":
                raise RuntimeError(f'Command MUST start with "--"!')
            else:
                cmd = unknown[1:]
        else:
            cmd = []

        skip_run = known.skip_run
        clobber = known.clobber
        if known.context_buffer_size is not None:
            context_buffer_size = SModelRun.parse_context_buffer_size(
                known.context_buffer_size
            )
        else:
            context_buffer_size = (
                1 << 30
            )  # 1GB fallback, may be overridden by auto-detection

        working_dir: Path = parse_arg(
            known.working_dir, ctor=Path, default=Path(os.getcwd())
        )
        base_output_dir: Path = parse_arg(
            known.output_dir, ctor=Path, default=working_dir
        )


        injection_lib = parse_arg(known.use_injection_lib, ctor=Path)

        return SModelRun(
            cmd,
            skip_run,
            clobber,
            context_buffer_size,
            known.log_level,
            working_dir,
            base_output_dir,
            injection_lib,
        )

    @staticmethod
    def parse_context_buffer_size(s: str):
        if s.isdigit():
            return int(s)
        else:
            assert len(s) > 1 and s[-1] in (
                "k",
                "K",
                "m",
                "M",
                "g",
                "G",
            ), f"Invalid context buffer size => {s}"
            unit = 1
            if s[-1] in ("k", "K"):
                unit = 1 << 10
            elif s[-1] in ("m", "M"):
                unit = 1 << 20
            elif s[-1] in ("g", "G"):
                unit = 1 << 30

            base = int(s[:-1])
            return base * unit

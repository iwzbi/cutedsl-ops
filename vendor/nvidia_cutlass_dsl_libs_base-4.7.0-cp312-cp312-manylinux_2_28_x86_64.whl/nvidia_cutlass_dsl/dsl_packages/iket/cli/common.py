import argparse
import json
import os
from typing import Dict, Tuple, List, TextIO, Optional, Any, Callable
from pathlib import Path

from iket._core.smodel.iket import IketInstrumentPatchMode as PatchMode


def parse_arg(arg: Any, ctor: Optional[Callable] = None, default: Optional[Any] = None):
    if arg is not None:
        if ctor is not None:
            return ctor(arg)
        else:
            return arg
    else:
        return default


class InjectionConfig:
    def __init__(
        self,
        context_buffer_size: int,
        output_dir: Path,
        tool_name: str,
        tool_config: dict,
        log_level: str = "warn",
    ):
        self.context_buffer_size = context_buffer_size
        self.output_dir = output_dir
        self.tool_name = tool_name
        self.tool_config = tool_config
        self.log_level = log_level

    def to_dict(self):
        return {
            "bufferSize": self.context_buffer_size,
            "outputDir": str(self.output_dir),
            "logLevel": self.log_level,
            "toolName": self.tool_name,
            "toolConfig": self.tool_config,
        }

    def save(self, p: Path):
        with open(p, "w") as f:
            json.dump(self.to_dict(), f, indent=2)


class IketConfig:
    def __init__(
        self,
        max_ts_cnt_per_warp: int,
        app_instrument: Path,
        patch_mode: Optional[PatchMode] = None,
    ):
        self.max_ts_cnt_per_warp = max_ts_cnt_per_warp
        self.app_instrument = app_instrument  # path to the instrument config
        self.patch_mode = patch_mode  # None=auto-detect

    def to_dict(self):
        d = {
            "maxTsCntPerWarp": self.max_ts_cnt_per_warp,
            "appInstrument": str(self.app_instrument),
        }
        if self.patch_mode is not None:
            d["patchMode"] = int(self.patch_mode)
            d["discoveryMode"] = int(self.patch_mode)  # backward compat
        return d

    def save(self, p: Path):
        with open(p, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

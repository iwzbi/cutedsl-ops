import os
import json
import argparse
import shutil
from pathlib import Path
from typing import List, Tuple, Dict, Optional
from subprocess import run, PIPE, STDOUT
from ..utils import iket_print

from ..profiler import (
    TrackerRecord,
    Calltrack,
    KernelSpec,
    IketModuleConfig,
    generate_kernel_spec,
    module_select_resource,
    generate_config,
    IketPostprocessorV2,
    InstrumentConfig,
)
from ..profiler.utils import compute_required_buffer_size
from .common import parse_arg, IketConfig
from .base import SModelRun
from .._build_config import EXTERNAL_RELEASE

INTERMEDIATE_OUTPUT_DIRS = ("tracker", "gen-config", "iket")


def configure_iket(parser: argparse.ArgumentParser):
    """
    configure iket parser for profile command
    """
    default_postprocess = "perfetto" if EXTERNAL_RELEASE else "none"
    parser.add_argument(
        "--use-config",
        type=str,
        help="use given config instead of auto-generated config",
    )
    parser.add_argument(
        "--use-tracker-dir", type=str, help="use given tracker dir and skip dryrun"
    )
    parser.add_argument(
        "--use-calltrack-dir",
        type=str,
        help="use given calltrack dir and skip calltrack",
    )
    parser.add_argument(
        "--use-calltrack-tool", type=str, help="optional tool to track indirect call"
    )
    parser.add_argument(
        "--max-ts-cnt-per-warp",
        type=int,
        default=None,
        help="Tell profiler how many timestamps is possibly stored per warp as a hint to let profiler allocate buffer properly. Default: None auto detect from tracker",
        dest="max_ts_cnt_per_warp",
    )
    parser.add_argument(
        "--config-version",
        type=str,
        choices=["v0", "v1"],
        default="v0",
        help="version of automatically generated iket2 instrument config, default: v0",
    )
    parser.add_argument(
        "--postprocess",
        type=str,
        choices=["perfetto", "json", "html", "none", "all"],
        default=default_postprocess,
        help="specify the post process option",
    )
    parser.add_argument(
        "--keep",
        action=argparse.BooleanOptionalAction,
        default=not EXTERNAL_RELEASE,
        help="keep intermediate profiling outputs. Default: true for internal builds, false for external releases",
    )
    parser.add_argument(
        "--warp-trace",
        dest="warp_trace",
        action="store_true",
        help=(
            "Enable warp-trace profiling: every non-internal kernel launch uses the entry/exit "
            "trampoline to record warp lifetimes, while body SASS is left unpatched and the "
            "tracker pre-pass is skipped."
        ),
    )
    # entrypoint for the subparser
    parser.set_defaults(func=run_iket)


def merge_instrument_configs(configs: List[InstrumentConfig]) -> InstrumentConfig:
    if len(configs) == 0:
        return InstrumentConfig({"version": 0}, [])
    merged_cfg = InstrumentConfig(configs[0].meta, [])
    for cfg in configs:
        for kernel_cfg in cfg.configs:
            merged_cfg.configs.append(kernel_cfg)
    return merged_cfg


def make_calltrack(
    iket_modules: Dict[int, IketModuleConfig],
    tracker_record: TrackerRecord,
    runner: SModelRun,
    calltrack_tool_path: Path,
):
    calltrack_specs: List[KernelSpec] = []
    for module_id, module in iket_modules.items():
        for name, func in module.sass_module.funcs.items():
            if (module_id, name) in tracker_record.launched_kernels:
                calltrack_kernel_spec = generate_kernel_spec(
                    name,
                    func,
                    tracker_record.driver_patch_offset_dict[module_id][name],
                )
                if calltrack_kernel_spec.points:
                    calltrack_specs.append(calltrack_kernel_spec)

    calltrack_dir = runner.working_dir / "call-track"
    if not calltrack_dir.exists():
        calltrack_dir.mkdir()

    calltrack_targets_path = calltrack_dir / "calltrack.targets.json"
    calltrack_record_path = calltrack_dir / "calltrack.result.json"
    with open(calltrack_targets_path, "w") as f:
        d = [spec.to_dict() for spec in calltrack_specs]
        json.dump(d, f, indent=2)

    extra_env = {
        "TARGETS_CONFIG": str(calltrack_targets_path),
        "OUTPUT_PATH": str(calltrack_record_path),
        "LD_PRELOAD": str(calltrack_tool_path),
    }

    runner.launch_gpu_workload(
        "", {}, job="call-track", force_run=True, extra_env=extra_env
    )
    assert calltrack_record_path.exists(), "Error: the result of calltrack is missing"
    with open(calltrack_record_path, "r") as f:
        d = json.load(f)
        calltrack = Calltrack.make_calltrack(d)

    return calltrack


def run_tracker_and_generate_config(
    known: argparse.Namespace,
    runner: SModelRun,
) -> Tuple[int, Path, Optional[int]]:
    """
    Run tracker pass and generate instrument config.
    Returns (max_ts_cnt_per_warp, instrument_config_path, computed_buffer_size_or_none).
    """
    if known.use_config:
        instrument_config_path = Path(known.use_config)
        assert instrument_config_path.exists()
        with open(instrument_config_path, "r") as f:
            instrument_config_data = json.load(f)
        max_ts_cnt_per_warp = max(
            cfg["maxTsCntPerWarp"] for cfg in instrument_config_data["configs"]
        )
        return max_ts_cnt_per_warp, instrument_config_path, None

    if not known.use_tracker_dir:
        iket_print(
            "============= Dry run application first to collect some info... ============="
        )
        result = runner.launch_gpu_workload(
            "tracker", {}, force_run=True, job="tracker"
        )
        if result.returncode != 0:
            iket_print(f"Tracker failed with return code: {result.returncode}")
            exit(1)
        tracker_dir = runner.get_output_dir("tracker")
    else:
        tracker_dir = Path(known.use_tracker_dir)

    tracker_dirs = []
    for subdir in tracker_dir.iterdir():
        if subdir.name.startswith("pid"):
            tracker = os.path.join(subdir, "tracker.json")
            if os.path.exists(tracker):
                tracker_dirs.append(subdir)
            else:
                iket_print("Tracker json not found in ", subdir)

    if known.max_ts_cnt_per_warp is None:
        recommended_max_ts_cnt_per_warp = None
        for process_tracker_dir in tracker_dirs:
            tracker_json_path = process_tracker_dir / "tracker.json"
            if tracker_json_path.exists():
                with open(tracker_json_path, "r") as f:
                    tracker_data = json.load(f)
                    if tracker_data is None:
                        iket_print(
                            f"Warning: tracker.json at {tracker_json_path} is empty or invalid"
                        )
                        continue
                    if "recommended_max_ts_cnt_per_warp" in tracker_data:
                        recommended_max_ts_cnt_per_warp = tracker_data[
                            "recommended_max_ts_cnt_per_warp"
                        ]
                        break
                    else:
                        iket_print(
                            f"Warning: 'recommended_max_ts_cnt_per_warp' not found in {tracker_json_path}"
                        )
                        continue
        assert (
            recommended_max_ts_cnt_per_warp is not None
        ), "recommended_max_ts_cnt_per_warp is not found in tracker"
        max_ts_cnt_per_warp = recommended_max_ts_cnt_per_warp
    else:
        max_ts_cnt_per_warp = known.max_ts_cnt_per_warp
        print(f"\nUsing user-specified max-ts-cnt-per-warp: {max_ts_cnt_per_warp}\n")

    gen_config_dir = runner.get_output_dir("gen-config")
    if not gen_config_dir.exists():
        gen_config_dir.mkdir()

    all_cfgs: List[InstrumentConfig] = []
    tracker_records_with_configs = []
    for process_tracker_dir in tracker_dirs:
        tracker_record = TrackerRecord.parse_json(process_tracker_dir / "tracker.json")
        iket_modules = tracker_record.make_iket_modules()
        calltrack: Optional[Calltrack] = None
        modules_configs: Dict[int, IketModuleConfig] = {}
        for module_id, iket_module in iket_modules.items():
            modules_configs[module_id] = module_select_resource(
                iket_module, max_ts_cnt_per_warp, calltrack
            )
        configs = generate_config(
            known.config_version,
            modules_configs,
            max_ts_cnt_per_warp,
        )
        all_cfgs.append(configs)
        tracker_records_with_configs.append((tracker_record, modules_configs))

    merged_cfg = merge_instrument_configs(all_cfgs)
    instrument_config_path = gen_config_dir / "instrument.config.json"
    with open(instrument_config_path, "w") as f:
        json.dump(merged_cfg.to_dict(), f, indent=2)

    computed_buffer_size = compute_required_buffer_size(
        tracker_records_with_configs, max_ts_cnt_per_warp
    )

    return max_ts_cnt_per_warp, instrument_config_path, computed_buffer_size


def postprocess_results(
    known: argparse.Namespace,
    runner: SModelRun,
    instrument_config_path: Path,
    iket_job: str = "iket",
):
    """Run post-processing on decoded results."""
    iket_output_dir = runner.get_output_dir(iket_job)
    cubin_json_path = None
    use_tracker_dir = getattr(known, "use_tracker_dir", None)
    tracker_output_dir = (
        Path(use_tracker_dir) if use_tracker_dir else runner.get_output_dir("tracker")
    )
    if tracker_output_dir.exists():
        for subdir in tracker_output_dir.iterdir():
            if subdir.name.startswith("pid"):
                cubin_json_path = subdir / "tracker.json"
                break

    for subdir in iket_output_dir.iterdir():
        if subdir.name.startswith("pid"):
            pid = subdir.name.split("_")[1]
            decoded_results_path = subdir / "iket.decoded_results.json"
            iket_postprocess_dir = runner.get_output_dir()
            processor = IketPostprocessorV2(
                instrument_config_path,
                decoded_results_path,
                iket_postprocess_dir,
                cubin_json_path,
            )
            trace_bytes = None
            if known.postprocess in ["perfetto", "html", "all"]:
                trace_bytes = processor.dump_perfetto(
                    iket_postprocess_dir / f"iket_pid_{pid}.pftrace"
                )
            if known.postprocess in ["json", "all"]:
                processor.dump_json(iket_postprocess_dir / f"iket_pid_{pid}.trace.json")
            if known.postprocess in ["html", "all"]:
                processor.dump_perfetto_html(
                    iket_postprocess_dir / f"iket_pid_{pid}.html", trace_bytes
                )


def is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def get_cleanup_protected_paths(known: argparse.Namespace) -> List[Path]:
    protected_paths = []
    for attr in ("use_tracker_dir", "use_config"):
        path = getattr(known, attr, None)
        if path:
            protected_paths.append(Path(path).expanduser().resolve(strict=False))
    return protected_paths


def cleanup_intermediate_outputs(known: argparse.Namespace, runner: SModelRun):
    """Remove intermediate workflow directories after a successful profiling run."""
    if known.postprocess == "none":
        iket_print(
            "Warning: --postprocess none requested with --no-keep; no final trace artifact will remain."
        )

    output_dir = runner.get_output_dir()
    protected_paths = get_cleanup_protected_paths(known)
    for dirname in INTERMEDIATE_OUTPUT_DIRS:
        intermediate_dir = output_dir / dirname
        if intermediate_dir.exists():
            if intermediate_dir.is_symlink() or not intermediate_dir.is_dir():
                iket_print(
                    f"Skipping non-directory intermediate output path: {intermediate_dir}"
                )
                continue
            intermediate_path = intermediate_dir.expanduser().resolve(strict=False)
            if any(is_relative_to(path, intermediate_path) for path in protected_paths):
                iket_print(
                    f"Skipping intermediate output directory containing a user-supplied path: {intermediate_dir}"
                )
                continue
            iket_print(f"Removing intermediate output directory: {intermediate_dir}")
            shutil.rmtree(intermediate_dir)


def should_cleanup_intermediate_outputs(
    known: argparse.Namespace, runner: SModelRun, iket_result
) -> bool:
    return not runner.skip_run and not known.keep and iket_result.returncode == 0


def make_warp_trace_stub_config(runner: SModelRun) -> Path:
    """Write a minimal empty instrument config for warp-trace mode.

    Warp-trace mode never reads kernel-specific instrument info, but the IKET tool config
    still expects an appInstrument JSON path. Provide an empty v0 config so the C++
    side can parse it into an empty AppInstrument and move on.
    """
    gen_config_dir = runner.get_output_dir("gen-config")
    if not gen_config_dir.exists():
        gen_config_dir.mkdir()
    stub_path = gen_config_dir / "instrument.config.json"
    with open(stub_path, "w") as f:
        json.dump({"meta": {"version": 0}, "configs": []}, f)
    return stub_path


def run_iket(known: argparse.Namespace, unknown: List[str]):
    runner = SModelRun.create(known, unknown, require_cmd=True)

    patch_mode_override = None
    if known.warp_trace:
        # Warp-trace mode: trampoline writes warp_start (header) + 4-byte warp_end (fixed slot)
        # for every launch; no body SASS patching, no per-instrument-point configs needed.
        # Skip the tracker pass entirely — its outputs (max_ts_cnt_per_warp, PMTRIG configs)
        # are all unused here. ts_cnt is always 1.
        from iket._core.smodel.iket import IketInstrumentPatchMode as PatchMode

        patch_mode_override = PatchMode.kWarpTrace
        max_ts_cnt_per_warp = 1
        instrument_config_path = make_warp_trace_stub_config(runner)
        computed_buffer_size = None
        iket_print(
            "Warp-trace mode enabled: tracker pass skipped, trampoline-only profiling. "
            "Use this run to capture warp lifetimes without body instrumentation."
        )
    else:
        # Pass 1: Tracker + config generation
        (
            max_ts_cnt_per_warp,
            instrument_config_path,
            computed_buffer_size,
        ) = run_tracker_and_generate_config(known, runner)

    # Apply auto-computed buffer size if user did not explicitly set one.
    # computed_buffer_size semantics:
    #   None  = no tracker data (e.g. --use-config or --warp-trace), keep the 1GB fallback
    #   0     = tracker ran, all launches are UTraceEvent-only, no buffer needed
    #   >0    = tracker ran, computed the required buffer size
    if known.context_buffer_size is None and computed_buffer_size is not None:
        runner.context_buffer_size = computed_buffer_size
        if computed_buffer_size == 0:
            iket_print(
                "No timestamp buffer needed (UTraceEvent-only workload), "
                "skipping context buffer allocation."
            )
        else:
            size_gb = computed_buffer_size / (1 << 30)
            iket_print(
                f"Auto-computed context buffer size: "
                f"{size_gb:.2f} GB "
                f"({computed_buffer_size:,} bytes)"
            )
            if size_gb > 10:
                iket_print(
                    f"WARNING: IKET will allocate {size_gb:.2f} GB of device memory for "
                    f"warp buffers. This may cause the workload to run out of GPU memory. "
                    f"Consider using --context-buffer-size to set a smaller value, or reduce "
                    f"the number of instrumented kernel launches."
                )

    tool_config = IketConfig(
        max_ts_cnt_per_warp, instrument_config_path, patch_mode=patch_mode_override
    )
    iket_print("============= Run application for real profiling... =============")
    iket_result = runner.launch_gpu_workload("iket", tool_config.to_dict(), job="iket")

    if (
        not runner.skip_run
        and known.postprocess != "none"
        and iket_result.returncode == 0
    ):
        postprocess_results(known, runner, instrument_config_path, "iket")

    if should_cleanup_intermediate_outputs(known, runner, iket_result):
        cleanup_intermediate_outputs(known, runner)

    return iket_result

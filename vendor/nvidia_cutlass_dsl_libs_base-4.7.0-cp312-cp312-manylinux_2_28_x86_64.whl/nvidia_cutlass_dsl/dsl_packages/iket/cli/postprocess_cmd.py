import argparse
from pathlib import Path
from typing import List, Optional


def configure_postprocess(parser: argparse.ArgumentParser):
    """Configure parser for the postprocess subcommand."""
    parser.add_argument(
        "run_dir",
        type=str,
        help="Path to an existing IKET run output directory",
    )
    parser.add_argument(
        "--format",
        type=str,
        choices=["perfetto", "html", "all"],
        default="all",
        help="Output format (default: all)",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Output directory for generated files (default: same as run_dir)",
    )
    parser.set_defaults(func=postprocess)


class _PostprocessResult:
    """Minimal result object matching the interface expected by entrypoint()."""

    def __init__(self, returncode: int):
        self.returncode = returncode


def _iket_print(*args, **kwargs):
    try:
        from ..utils import iket_print

        iket_print(*args, **kwargs)
    except Exception:
        print("[run-iket]", *args, **kwargs)


def _find_instrument_config(run_dir: Path) -> Path:
    gen_config = run_dir / "gen-config" / "instrument.config.json"
    if gen_config.exists():
        return gen_config

    direct = run_dir / "instrument.config.json"
    if direct.exists():
        return direct

    raise FileNotFoundError(
        f"Cannot find instrument.config.json in {run_dir}. "
        "Expected at gen-config/instrument.config.json"
    )


def _find_cubin_json(run_dir: Path) -> Optional[Path]:
    tracker_dir = run_dir / "tracker"
    if not tracker_dir.exists():
        return None

    for subdir in tracker_dir.iterdir():
        if subdir.name.startswith("pid"):
            candidate = subdir / "tracker.json"
            if candidate.exists():
                return candidate
    return None


def postprocess(known: argparse.Namespace, unknown: List[str]):
    """Run postprocessing on an existing IKET run directory."""
    del unknown

    run_dir = Path(known.run_dir).resolve()
    if not run_dir.is_dir():
        _iket_print(f"Error: run directory does not exist: {run_dir}")
        return _PostprocessResult(1)

    output_dir = Path(known.output_dir).resolve() if known.output_dir else run_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        instrument_config_path = _find_instrument_config(run_dir)
    except FileNotFoundError as exc:
        _iket_print(f"Error: {exc}")
        return _PostprocessResult(1)

    iket_output_dir = run_dir / "iket"
    if not iket_output_dir.is_dir():
        _iket_print(f"Error: no iket/ subdirectory found in {run_dir}")
        return _PostprocessResult(1)

    from ..profiler.postprocess import IketPostprocessorV2

    cubin_json_path = _find_cubin_json(run_dir)
    processed = 0

    for subdir in sorted(iket_output_dir.iterdir()):
        if not subdir.name.startswith("pid"):
            continue

        pid = subdir.name.split("_")[1]
        decoded_results_path = subdir / "iket.decoded_results.json"
        if not decoded_results_path.exists():
            _iket_print(f"Warning: no decoded results found in {subdir}, skipping")
            continue

        _iket_print(f"Post-processing results for pid {pid}...")
        processor = IketPostprocessorV2(
            instrument_config_path,
            decoded_results_path,
            output_dir,
            cubin_json_path,
        )

        trace_bytes = None
        if known.format in ["perfetto", "html", "all"]:
            perfetto_path = output_dir / f"iket_pid_{pid}.pftrace"
            trace_bytes = processor.dump_perfetto(perfetto_path)
            _iket_print(f"  -> {perfetto_path}")

        if known.format in ["html", "all"]:
            html_path = output_dir / f"iket_pid_{pid}.html"
            processor.dump_perfetto_html(html_path, trace_bytes)
            _iket_print(f"  -> {html_path}")

        processed += 1

    if processed == 0:
        _iket_print("Error: no pid_* directories with decoded results found")
        return _PostprocessResult(1)

    _iket_print(f"Post-processing complete. {processed} pid(s) processed.")
    return _PostprocessResult(0)

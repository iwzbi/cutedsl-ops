from enum import Enum
from typing import Dict, Tuple

class IketInstrumentMethod(Enum):
    kPMTrig5: "IketInstrumentMethod"
    kPMTrig6: "IketInstrumentMethod"
    kNativeDump: "IketInstrumentMethod"
    kUTraceEvent: "IketInstrumentMethod"
    kExtendedNativeDump: "IketInstrumentMethod"

class IketEvtAttributes:
    event_id: int
    instrument_method: IketInstrumentMethod
    payload_type: IketEvtPayloadType

class IketKernelInstrumentPoint:
    offset_start: int
    offset_end: int
    evt_attr: IketEvtAttributes

class IketEventPos(Enum):
    kNotInRange: "IketEventPos"
    kRangeStart: "IketEventPos"
    kRangeEnd: "IketEventPos"
    kRangeInternal: "IketEventPos"
    kRangeStartEnd: "IketEventPos"

class IketEventSummary:
    name: str
    range_pos: IketEventPos
    instrument_method: IketInstrumentMethod

class IketContext:
    @staticmethod
    def create(cubin: bytes) -> IketContext: ...
    def get_events() -> dict[int, IketEventSummary]: ...
    def get_kernel_instrument_points(
        self, kernel: str
    ) -> list[IketKernelInstrumentPoint]: ...

class IketEvtPayloadType(Enum):
    kNoPayload: "IketEvtPayloadType"
    kI8: "IketEvtPayloadType"
    kUI8: "IketEvtPayloadType"
    kI16: "IketEvtPayloadType"
    kUI16: "IketEvtPayloadType"
    kI32: "IketEvtPayloadType"
    kUI32: "IketEvtPayloadType"
    kFP4: "IketEvtPayloadType"
    kFP8: "IketEvtPayloadType"
    kFP16: "IketEvtPayloadType"
    kUI64: "IketEvtPayloadType"

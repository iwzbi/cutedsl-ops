from typing import List, Iterable
from pathlib import Path
import importlib.resources
from ._core.smodel.iket import IketEvtPayloadType

iket_evt_payload_type_to_str = {
    IketEvtPayloadType.kNoPayload: "NoPayload",
    IketEvtPayloadType.kI8: "I8",
    IketEvtPayloadType.kUI8: "UI8",
    IketEvtPayloadType.kI16: "I16",
    IketEvtPayloadType.kUI16: "UI16",
    IketEvtPayloadType.kI32: "I32",
    IketEvtPayloadType.kUI32: "UI32",
    IketEvtPayloadType.kFP4: "FP4",
    IketEvtPayloadType.kFP8: "FP8",
    IketEvtPayloadType.kFP16: "FP16",
    IketEvtPayloadType.kBF16: "BF16",
    IketEvtPayloadType.kFP32: "FP32",
    IketEvtPayloadType.kPointer: "Pointer",
    IketEvtPayloadType.kUI64: "UI64",
    IketEvtPayloadType.kI64: "I64",
    IketEvtPayloadType.kFP64: "FP64",
}


def _fp16_bits_to_float(bits: int) -> float:
    """Convert IEEE 754 half-precision (FP16) bits to Python float."""
    sign = (bits >> 15) & 0x1
    exp = (bits >> 10) & 0x1F
    frac = bits & 0x3FF

    if exp == 0:
        if frac == 0:
            return -0.0 if sign else 0.0
        # Subnormal number
        return ((-1) ** sign) * (2**-14) * (frac / 1024)
    elif exp == 0x1F:
        if frac == 0:
            return float("-inf") if sign else float("inf")
        return float("nan")
    else:
        return ((-1) ** sign) * (2 ** (exp - 15)) * (1 + frac / 1024)


def iket_print(*args, **kwargs):
    print("[run-iket]", *args, **kwargs)


def get_binary_files_with_war(package: str, *filenames: Iterable[str]) -> List[Path]:
    ret = []

    for filename in filenames:
        if importlib.resources.is_resource(package, filename):
            with importlib.resources.path(package, filename) as resource_path:
                p = Path(resource_path)
        else:
            # For now scikit-build-core does dot support resource file well with editable install
            # TODO: use importlib.resource when scikit-build-core supports editable install well
            import sysconfig

            # site-packages/
            root_dir = Path(sysconfig.get_path("purelib"))
            p = root_dir / package.replace(".", "/") / filename
        ret.append(Path(p))
    return ret

from enum import IntEnum
from typing import List, Optional, Final, Dict, Union, Tuple
from dataclasses import dataclass

class RangeScope(IntEnum):
    INTRA_WARP: Final[int] = 0
    INTER_WARP_IN_CTA: Final[int] = 1  # 0x1 << 0
    INTER_WARP_IN_SM: Final[int] = 2  # 0x1 << 1
    INTER_WARP_IN_TPC: Final[int] = 4  # 0x1 << 2
    INTER_WARP_IN_GPC: Final[int] = 8  # 0x1 << 3

class RangeType(IntEnum):
    INVALID: Final[int] = 0
    START_END: Final[int] = 1
    PUSH_POP: Final[int] = 2
    MULTI_EVENT: Final[int] = 3

class EventPairMode(IntEnum):
    INVALID: Final[int] = 0
    NAME_ONLY: Final[int] = 1
    NAME_AND_PAYLOAD: Final[int] = 2

class EventPos(IntEnum):
    NOT_IN_RANGE: Final[int] = 0
    RANGE_START: Final[int] = 1
    RANGE_END: Final[int] = 2
    RANGE_START_END: Final[int] = 4
    RANGE_INTERNAL: Final[int] = 8

class InstrumentMethod(IntEnum):
    PMTRIG5: Final[int] = 1
    PMTRIG6: Final[int] = 2
    NATIVE_DUMP: Final[int] = 3
    UTRACE_EVENT: Final[int] = 4
    EXTENDED_NATIVE_DUMP: Final[int] = 5

class PayloadType(IntEnum):
    NO_PAYLOAD: Final[int] = 0
    I8: Final[int] = 1
    UI8: Final[int] = 2
    I16: Final[int] = 3
    UI16: Final[int] = 4
    I32: Final[int] = 5
    UI32: Final[int] = 6
    I64: Final[int] = 7
    FP4: Final[int] = 9
    FP8: Final[int] = 10
    FP16: Final[int] = 11
    BF16: Final[int] = 12
    FP32: Final[int] = 13
    FP64: Final[int] = 14
    POINTER: Final[int] = 15

class Colors(IntEnum):
    AUTO: Final[int] = -1
    BLACK: Final[int] = 0x000000
    WHITE: Final[int] = 0xFFFFFF
    RED: Final[int] = 0xFF0000
    GREEN: Final[int] = 0x00FF00
    BLUE: Final[int] = 0x0000FF
    YELLOW: Final[int] = 0xFFFF00
    CYAN: Final[int] = 0x00FFFF
    MAGENTA: Final[int] = 0xFF00FF
    ORANGE: Final[int] = 0xFFA500
    PURPLE: Final[int] = 0x800080
    GRAY: Final[int] = 0x808080
    LIGHT_GRAY: Final[int] = 0xD3D3D3
    DARK_GRAY: Final[int] = 0xA9A9A9
    BROWN: Final[int] = 0xA52A2A
    PINK: Final[int] = 0xFFC0CB
    LIGHT_GREEN: Final[int] = 0x90EE90
    LIGHT_BLUE: Final[int] = 0xADD8E6

class TimestampType(IntEnum):
    UINT64: Final[int] = 0
    UINT32: Final[int] = 1
    FLOAT: Final[int] = 2

@dataclass
class MetaInfo:
    version_major: int
    version_minor: int
    max_event_id: int
    max_event_name_size: int
    supported_features: int
    magic_number: int
    legacy_iket_cubin: bool

@dataclass
class MultiEventRangeAttrs:
    range_name: str
    range_id: int
    range_scope: RangeScope
    range_type: RangeType
    evt_pair_mode: EventPairMode
    color: Colors

@dataclass
class EvtAttributes:
    event_name: str
    event_id: int
    instrument_method: InstrumentMethod
    payload_type: PayloadType
    event_pos: EventPos
    range_id: int

@dataclass
class KernelInstrumentPoint:
    offset_start: int
    offset_end: int
    has_payload: bool
    payload_reg_index: int
    event_attr: EvtAttributes

@dataclass
class KernelInfo:
    kernel_name: str
    instrument_points: List[KernelInstrumentPoint]

@dataclass
class EventLocation:
    sm_id: int
    tpc_id: int
    gpc_id: int
    cluster_id: Tuple[int, int, int]  # Fixed-size array of 3 elements
    cta_id: Tuple[int, int, int]  # Fixed-size array of 3 elements
    warp_id: int

@dataclass
class EventRecord:
    timestamp: Union[int, float]  # Can be u64, u32, or f32
    event_id: int
    payload_type: PayloadType
    payload_val: Union[int, float] = 0

@dataclass
class Activities:
    timestamp_type: TimestampType
    warp_location: EventLocation
    events: List[EventRecord]

@dataclass
class RangeSpan:
    range_id: int
    range_name: str
    range_color: Colors
    range_scope: RangeScope
    start_ts: Union[int, float]
    end_ts: Union[int, float]
    internal_events: List[EventRecord]
    warp_locs: List[EventLocation]

@dataclass
class Marker:
    location: EventLocation
    timestamp: Union[int, float]
    marker_name: str
    color: Colors
    payload_type: PayloadType
    payload_val: Union[int, float] = 0

@dataclass
class Trace:
    ranges: List[RangeSpan]
    markers: List[Marker]

class Context:
    def __init__(self, cubin_data: bytes) -> None: ...
    def is_instrumented(self) -> bool: ...
    def get_meta_info(self) -> MetaInfo: ...
    def get_all_ranges(self) -> List[MultiEventRangeAttrs]: ...
    def get_all_events(self) -> List[EvtAttributes]: ...
    def get_range_events(self, range_id: int) -> List[EvtAttributes]: ...
    def get_event_range(self, event_id: int) -> MultiEventRangeAttrs: ...
    def get_kernels_instrument_info(self) -> List[KernelInfo]: ...

class Profiler:
    def __init__(self, ctx: Context) -> None: ...
    def is_valid(self) -> bool: ...
    def generate_trace(self, activities: List[Activities], flags: int = 0) -> Trace: ...

from .iket_lib import PyIketContext as Context
from .iket_lib import PyIketProfiler as Profiler
from .iket_lib import (
    ReservedZeroEventId,
    ReservedRangePopEventId,
    UTraceRangePopEventId,
)

from enum import IntEnum
from dataclasses import dataclass
from typing import List, Optional, Final, Dict, Union, Tuple


class RangeScope(IntEnum):
    INTRA_WARP = 0
    INTER_WARP_IN_CTA = 1  # 0x1 << 0
    INTER_WARP_IN_SM = 2  # 0x1 << 1
    INTER_WARP_IN_TPC = 4  # 0x1 << 2
    INTER_WARP_IN_GPC = 8  # 0x1 << 3


class RangeType(IntEnum):
    INVALID = 0
    START_END = 1
    PUSH_POP = 2
    MULTI_EVENT = 3


class EventPairMode(IntEnum):
    INVALID = 0
    NAME_ONLY = 1
    NAME_AND_PAYLOAD = 2


class EventPos(IntEnum):
    NOT_IN_RANGE = 0
    RANGE_START = 1
    RANGE_END = 2
    RANGE_START_END = 4
    RANGE_INTERNAL = 8


class InstrumentMethod(IntEnum):
    PMTRIG5 = 1
    PMTRIG6 = 2
    NATIVE_DUMP = 3
    UTRACE_EVENT = 4
    EXTENDED_NATIVE_DUMP = 5


class PayloadType(IntEnum):
    NO_PAYLOAD = 0
    I8 = 1
    UI8 = 2
    I16 = 3
    UI16 = 4
    I32 = 5
    UI32 = 6
    I64 = 7
    FP4 = 9
    FP8 = 10
    FP16 = 11
    BF16 = 12
    FP32 = 13
    FP64 = 14
    POINTER = 15
    UI64 = 16


class Colors(IntEnum):
    AUTO = -1
    BLACK = 0x000000
    WHITE = 0xFFFFFF
    RED = 0xFF0000
    GREEN = 0x00FF00
    BLUE = 0x0000FF
    YELLOW = 0xFFFF00
    CYAN = 0x00FFFF
    MAGENTA = 0xFF00FF
    ORANGE = 0xFFA500
    PURPLE = 0x800080
    GRAY = 0x808080
    LIGHT_GRAY = 0xD3D3D3
    DARK_GRAY = 0xA9A9A9
    BROWN = 0xA52A2A
    PINK = 0xFFC0CB
    LIGHT_GREEN = 0x90EE90
    LIGHT_BLUE = 0xADD8E6


class TimestampType(IntEnum):
    UINT64 = 0
    UINT32 = 1
    FLOAT = 2


@dataclass
class MetaInfo:
    version_major: int
    version_minor: int
    max_event_id: int
    max_event_name_size: int
    supported_features: int
    magic_number: int
    legacy_iket_cubin: bool


@dataclass
class MultiEventRangeAttrs:
    range_name: str
    range_id: int
    range_scope: RangeScope
    range_type: RangeType
    evt_pair_mode: EventPairMode
    color: Colors


@dataclass
class EvtAttributes:
    event_name: str
    event_id: int
    instrument_method: InstrumentMethod
    payload_type: PayloadType
    event_pos: EventPos
    range_id: int


@dataclass
class KernelInstrumentPoint:
    offset_start: int
    offset_end: int
    event_attr: EvtAttributes


@dataclass
class KernelInfo:
    kernel_name: str
    instrument_points: List[KernelInstrumentPoint]


@dataclass
class EventLocation:
    sm_id: int
    tpc_id: int
    gpc_id: int
    cluster_id: Tuple[int, int, int]  # Fixed-size array of 3 elements
    cta_id: Tuple[int, int, int]  # Fixed-size array of 3 elements
    warp_id: int


@dataclass
class EventRecord:
    timestamp: Union[int, float]  # Can be u64, u32, or f32
    event_id: int
    payload_type: PayloadType
    payload_val: Union[int, float] = 0


@dataclass
class Activities:
    timestamp_type: TimestampType
    warp_location: EventLocation
    events: List[EventRecord]


@dataclass
class RangeSpan:
    range_id: int
    range_name: str
    range_color: Colors
    range_scope: RangeScope
    start_ts: Union[int, float]
    end_ts: Union[int, float]
    internal_events: List[EventRecord]
    warp_locs: List[EventLocation]


@dataclass
class Marker:
    location: EventLocation
    timestamp: Union[int, float]
    marker_name: str
    color: Colors
    payload_type: PayloadType
    payload_val: Union[int, float] = 0


@dataclass
class Trace:
    ranges: List[RangeSpan]
    markers: List[Marker]


__all__ = [
    "Context",
    "Profiler",
    "MetaInfo",
    "MultiEventRangeAttrs",
    "EvtAttributes",
    "KernelInstrumentPoint",
    "KernelInfo",
    "EventLocation",
    "EventRecord",
    "Activities",
    "RangeSpan",
    "Marker",
    "Trace",
    "RangeScope",
    "RangeType",
    "EventPairMode",
    "EventPos",
    "InstrumentMethod",
    "PayloadType",
    "Colors",
    "TimestampType",
    "ReservedZeroEventId",
    "ReservedRangePopEventId",
    "UTraceRangePopEventId",
]

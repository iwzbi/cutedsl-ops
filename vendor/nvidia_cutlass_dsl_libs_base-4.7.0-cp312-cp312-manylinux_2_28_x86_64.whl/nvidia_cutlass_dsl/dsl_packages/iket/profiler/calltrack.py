from typing import List, Dict, Set

# # from ...sass import Function, RegOp
# from smodel.sass import Module, Function


class IndirectCallSpec:
    def __init__(self, offset: int, reg_id: int):
        self.offset = offset
        self.reg_id = reg_id

    def to_dict(self):
        return {"offset": self.offset, "regId": self.reg_id}


class KernelSpec:
    def __init__(
        self, name: str, driver_patch_offset: int, points: List[IndirectCallSpec]
    ):
        self.name = name
        self.driver_patch_offset = driver_patch_offset
        self.points = points

    def to_dict(self):
        return {
            "name": self.name,
            "driverPatchOffset": self.driver_patch_offset,
            "points": [p.to_dict() for p in self.points],
        }

    def __repr__(self):
        return str(self.to_dict())


def generate_kernel_spec(name: str, func: "Function", driver_patch_offset: int):
    pass


#     points: List[IndirectCallSpec] = []
#     for instr in func.instrs:
#         if instr.opcode == "CALL" and instr.get_op_modifier_by_label("abs") == "ABS":
#             if instr.opclass == "call_abs__RRR":
#                 Ra = instr.get_reg_by_label("Ra")
#                 Ra_offset = instr.get_imm_by_label("Ra_offset")
#                 assert Ra_offset.imm == 0 and Ra.len == 2
#                 points.append(IndirectCallSpec(instr.pc, Ra.idx))
#             elif instr.opclass == "call_abs__RIR":
#                 Sa = instr.get_imm_by_label("Sa")
#                 assert Sa.imm == 0
#             else:
#                 assert False, f"Unsupported call opclass: {instr.opclass}"

#     return KernelSpec(name, driver_patch_offset, points)


class Calltrack:
    def __init__(self, record: Dict[str, Dict[int, Set[str]]]):
        self.records = record


#     @staticmethod
#     def make_calltrack(d: Dict):
#         grid_id_to_kernel: Dict[int, str] = {}
#         for l in d["launches"]:
#             grid_id = l["gridId"]
#             kernel = l["kernelName"]
#             grid_id_to_kernel[grid_id] = kernel

#         pc_to_function: Dict[int, str] = {}
#         for t in d["targets"]:
#             pc = t["addr"]
#             func = t["functionName"]
#             pc_to_function[pc] = func

#         record: Dict[str, Dict[int, Set[str]]] = {}
#         for r in d["records"]:
#             pc = r["addr"]
#             func = pc_to_function[pc]

#             grid_id = r["grid"]
#             kernel = grid_id_to_kernel[grid_id]

#             offset = r["offset"]

#             if kernel not in record:
#                 record[kernel] = {}
#             if offset not in record[kernel]:
#                 record[kernel][offset] = set()
#             record[kernel][offset].add(func)

#         return Calltrack(record)

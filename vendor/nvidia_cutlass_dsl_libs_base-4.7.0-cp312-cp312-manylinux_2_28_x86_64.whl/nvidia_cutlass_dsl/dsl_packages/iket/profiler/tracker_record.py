from typing import List, Dict, Set, Tuple
from os import PathLike, path
from pathlib import Path
import json

from ..core import IketContext, IketEventPos, IketInstrumentMethod, IketEventSummary
from .utils import IketModule


class TrackerDim3:
    def __init__(self, x: int, y: int, z: int):
        self.x = x
        self.y = y
        self.z = z

    def to_dict(self):
        return {"x": self.x, "y": self.y, "z": self.z}

    @staticmethod
    def from_dict(d: Dict):
        return TrackerDim3(d["x"], d["y"], d["z"])

    def __repr__(self):
        return str(self.to_dict())


class ParameterDeviceFunction:
    def __init__(self, name: str, offset: int, module_id: int, function_id: int):
        self.name = name
        self.offset = offset
        self.module_id = module_id
        self.function_id = function_id

    def to_dict(self):
        return {
            "name": self.name,
            "offset": self.offset,
            "moduleId": self.module_id,
            "functionId": self.function_id,
        }

    @staticmethod
    def from_dict(d: Dict):
        return ParameterDeviceFunction(
            d["name"], d["offset"], d["moduleId"], d["functionId"]
        )

    def __repr__(self):
        return f"ParameterDeviceFunction{{.name={self.name}, .offset={self.offset}, .module_id={self.module_id}, .function_id={self.function_id}}}"

    def __iter__(self):
        yield self.name
        yield self.offset
        yield self.module_id
        yield self.function_id


class TrackerLaunchRecord:
    def __init__(
        self,
        grid_dim: TrackerDim3,
        block_dim: TrackerDim3,
        context_id: int,
        function_id: int,
        module_id: int,
        kernel_name: str,
        driver_patch_offset: int,
        parameters_devfunc: List[ParameterDeviceFunction],
    ):
        self.grid_dim = grid_dim
        self.block_dim = block_dim
        self.context_id = context_id
        self.function_id = function_id
        self.module_id = module_id
        self.kernel_name = kernel_name
        self.driver_patch_offset = driver_patch_offset
        self.parameters_devfunc = parameters_devfunc

    def to_dict(self):
        return {
            "gridDim": self.grid_dim.to_dict(),
            "blockDim": self.block_dim.to_dict(),
            "contextId": self.context_id,
            "functionId": self.function_id,
            "moduleId": self.module_id,
            "kernelName": self.kernel_name,
            "driverPatchOffset": self.driver_patch_offset,
            "parametersDeviceFunciton": self.parameters_devfunc,
        }

    @staticmethod
    def from_dict(d: Dict):
        return TrackerLaunchRecord(
            TrackerDim3.from_dict(d["gridDim"]),
            TrackerDim3.from_dict(d["blockDim"]),
            d["contextId"],
            d["functionId"],
            d["moduleId"],
            d["kernelName"],
            d["driverPatchOffset"],
            [
                ParameterDeviceFunction.from_dict(pdf)
                for pdf in d["parametersDeviceFunction"]
            ],
        )


class TrackerModuleRecord:
    def __init__(self, image: str, size: int, module_id: int, handles: Dict[int, int]):
        self.image = image
        self.size = size
        self.module_id = module_id
        self.handles = handles

    def to_dict(self):
        return {
            "image": self.image,
            "size": self.size,
            "moduleId": self.module_id,
            "handles": self.handles,
        }

    @staticmethod
    def from_dict(d: Dict):
        handles = {context_id: int(mod, 16) for context_id, mod in d["handles"]}
        return TrackerModuleRecord(d["image"], d["size"], d["moduleId"], handles)

    def __repr__(self):
        return str(self.to_dict())


class TrackerRecord:
    def __init__(
        self,
        launches: List[TrackerLaunchRecord],
        modules: Dict[int, TrackerModuleRecord],
        graph_launches: Dict[str, List[TrackerLaunchRecord]] | None = None,
    ):
        self.launches = launches
        self.modules_records = modules
        self.graph_launches = graph_launches or {}
        launches_with_devfunc = [
            l for l in self.iterate_kernel_launches() if l.parameters_devfunc
        ]
        dev_func_related_modules = set()
        for l in launches_with_devfunc:
            dev_func_related_modules.add(l.module_id)
            for f in l.parameters_devfunc:
                dev_func_related_modules.add(f.module_id)
        # only need to care for those functions that been instrumented if they have device function
        self.has_parameter_device_function = (
            len(dev_func_related_modules & modules.keys()) > 0
        )
        self.launched_kernels: Set[Tuple[int, str]] = set(
            (l.module_id, l.kernel_name) for l in launches
        )
        self.driver_patch_offset_dict = TrackerRecord.collect_driver_patch_offset(
            launches
        )

    def iterate_kernel_launches(self):
        for l in self.launches:
            yield l
        for gl in self.graph_launches.values():
            for l in gl:
                yield l

    @staticmethod
    def collect_driver_patch_offset(launches: List[TrackerLaunchRecord]):
        ret: Dict[int, Dict[str, int]] = {}

        for l in launches:
            if l.module_id not in ret:
                ret[l.module_id] = {}

            if l.kernel_name not in ret[l.module_id]:
                ret[l.module_id][l.kernel_name] = l.driver_patch_offset
            else:
                assert ret[l.module_id][l.kernel_name] == l.driver_patch_offset

        return ret

    @staticmethod
    def from_dict(d: Dict):
        launches = []
        for l in d["launches"]:
            launch = TrackerLaunchRecord.from_dict(l)
            launches.append(launch)

        modules = {}
        for m in d["modules"]:
            module = TrackerModuleRecord.from_dict(m)
            modules[module.module_id] = module

        graph_launches: Dict[str, List[TrackerLaunchRecord]] = {}
        if "graphLaunches" in d:
            for key, gl in d["graphLaunches"].items():
                graph_launched_kernels = []
                for l in gl:
                    launch = TrackerLaunchRecord.from_dict(l)
                    graph_launched_kernels.append(launch)
                graph_launches[key] = graph_launched_kernels
        return TrackerRecord(launches, modules, graph_launches)

    @staticmethod
    def parse_json(j: PathLike):
        assert path.exists(j), f"Nonexist path: {j}"

        with open(j, "r") as f:
            d = json.load(f)
        return TrackerRecord.from_dict(d)

    def make_iket_modules(self):
        """
        make iket modules from the tracker record.

        return:
            modules: module id -> iket module
        """
        # Step-0: get all events in each module
        cubin_context: Dict[int, IketContext] = {}
        # module id -> event id -> iket event summary
        events: Dict[int, Dict[int, IketEventSummary]] = {}
        for module_id, module in self.modules_records.items():
            with open(module.image, "rb") as f:
                binary = f.read()
            ctx = IketContext.create(binary)
            events[module_id] = ctx.get_events()
            cubin_context[module_id] = ctx

        # Step-1: collect target functions (kernel or device)
        # module id -> function name
        target_functions: Dict[int, Set[str]] = {}

        def add_target(module_id: int, function_name: str):
            if module_id not in target_functions:
                target_functions[module_id] = set()

            # a device is target function if it's related to a launched kernel and belongs to a module instrumented by IKET
            # TODO: add more device function tracking methods: relocation, devfunc table, ...
            target_functions[module_id].add(function_name)

        for lr in self.iterate_kernel_launches():
            add_target(lr.module_id, lr.kernel_name)

            for param_devfun in lr.parameters_devfunc:
                add_target(param_devfun.module_id, param_devfun.name)

        # Step-2: generate iket modules
        # module id -> iket module
        modules: Dict[int, IketModule] = {}
        for module_id, module_events in events.items():
            functions = target_functions[module_id]
            # only those related functions are parsed
            mr = self.modules_records[module_id]
            mhash = mr.module_id
            size = mr.size
            modules[module_id] = IketModule(
                mr.image,
                module_id,
                mhash,
                size,
                functions,
                module_events,
                cubin_context[module_id],
            )

        return modules

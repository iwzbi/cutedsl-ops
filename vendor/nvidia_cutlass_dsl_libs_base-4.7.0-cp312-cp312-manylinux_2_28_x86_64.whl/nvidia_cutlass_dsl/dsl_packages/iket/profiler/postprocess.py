import json
import struct
import uuid
import gzip
from typing import List, Dict, Optional, Tuple, Union
from pathlib import Path
import itertools
from collections import defaultdict
from .._build_config import EXTERNAL_RELEASE
from ..core import IketEventPos, IketEvtPayloadType
from .perfetto_trace_pb2 import Trace, TracePacket, TrackEvent, TrackDescriptor
from .perfetto_viewer_template import HTML_TEMPLATE as _PERFETTO_HTML_TEMPLATE
from iket import (
    Context,
    Profiler,
    EventLocation,
    EventRecord,
    Activities,
    TimestampType,
    PayloadType,
    Trace as IketTrace,
    RangeScope,
    RangeSpan,
    Marker,
    RangeType,
)
from ..utils import iket_print, iket_evt_payload_type_to_str, _fp16_bits_to_float

_WARP_TRACK_KIND_ORDER = {
    "StartEnd": 0,
    "StackedRanges": 100,
    "Marker": 200,
}
_SORT_PHASE_SLICE_END = 0
_SORT_PHASE_INSTANT = 1
_SORT_PHASE_SLICE_BEGIN = 2
_SORT_PHASE_ZERO_DURATION_SLICE_END = 3

# Try to use orjson for faster JSON I/O (10-20x faster than stdlib json)
try:
    import orjson

    _has_orjson = True
except ImportError:
    _has_orjson = False


def _enum_int(e):
    """Return the integer value for nanobind and Python enum values."""
    try:
        return int(e)
    except TypeError:
        return e.value


_PAYLOAD_TYPE_NO_PAYLOAD = _enum_int(IketEvtPayloadType.kNoPayload)
_PAYLOAD_TYPE_STR_BY_INT: Dict[int, str] = {
    _enum_int(k): v for k, v in iket_evt_payload_type_to_str.items()
}
_PT_INT = {
    name: _enum_int(getattr(IketEvtPayloadType, name))
    for name in dir(IketEvtPayloadType)
    if name.startswith("k") and not name.startswith("__")
}
_RANGE_SCOPE_INTRA_WARP = _enum_int(RangeScope.INTRA_WARP)
_RANGE_SCOPE_INTER_WARP_IN_CTA = _enum_int(RangeScope.INTER_WARP_IN_CTA)
_RANGE_SCOPE_INTER_WARP_IN_SM = _enum_int(RangeScope.INTER_WARP_IN_SM)
_RANGE_SCOPE_INTER_WARP_IN_TPC = _enum_int(RangeScope.INTER_WARP_IN_TPC)
_RANGE_SCOPE_INTER_WARP_IN_GPC = _enum_int(RangeScope.INTER_WARP_IN_GPC)


class _PerfettoTrackEventBuffer:
    """Collect TrackEvent packets per track and emit them in Perfetto stack order."""

    def __init__(self):
        self._records_by_track = {}
        self._track_order = []
        self._original_indices = itertools.count()

    def add_slice(self, begin_packet, end_packet):
        begin_event = begin_packet.track_event
        end_event = end_packet.track_event
        track_uuid = begin_event.track_uuid
        if track_uuid != end_event.track_uuid:
            raise ValueError("Slice begin/end packets must use the same track UUID")

        original_index = next(self._original_indices)
        self._append_record(
            track_uuid,
            self._make_slice_sort_record(
                begin_packet,
                begin_packet,
                end_packet,
                is_end=False,
                original_index=original_index,
            ),
        )
        self._append_record(
            track_uuid,
            self._make_slice_sort_record(
                end_packet,
                begin_packet,
                end_packet,
                is_end=True,
                original_index=original_index,
            ),
        )

    def add_instant(self, packet):
        event = packet.track_event
        original_index = next(self._original_indices)
        self._append_record(
            event.track_uuid,
            {
                "packet": packet,
                "sort_key": (
                    packet.timestamp,
                    _SORT_PHASE_INSTANT,
                    (0, 0, original_index),
                    event.name,
                    original_index,
                ),
            },
        )

    def flush_to_trace(self, trace):
        for track_uuid in self._track_order:
            records = self._records_by_track[track_uuid]
            records.sort(key=lambda item: item["sort_key"])
            for record in records:
                trace.packet.add().CopyFrom(record["packet"])

    def _append_record(self, track_uuid, record):
        if track_uuid not in self._records_by_track:
            self._records_by_track[track_uuid] = []
            self._track_order.append(track_uuid)
        self._records_by_track[track_uuid].append(record)

    def _make_slice_sort_record(
        self, packet, start_packet, end_packet, is_end: bool, original_index: int
    ):
        event = packet.track_event
        start_ts = start_packet.timestamp
        end_ts = end_packet.timestamp
        duration = end_ts - start_ts
        zero_duration = duration == 0
        if zero_duration:
            phase = (
                _SORT_PHASE_ZERO_DURATION_SLICE_END
                if is_end
                else _SORT_PHASE_SLICE_BEGIN
            )
        else:
            phase = _SORT_PHASE_SLICE_END if is_end else _SORT_PHASE_SLICE_BEGIN

        if is_end:
            # Ends at the same timestamp must close inner slices before outer slices.
            nesting_key = (-start_ts, duration, -original_index)
        else:
            # Begins at the same timestamp must open outer slices before inner slices.
            nesting_key = (-end_ts, -duration, original_index)

        return {
            "packet": packet,
            "sort_key": (
                packet.timestamp,
                phase,
                nesting_key,
                event.name,
                original_index,
            ),
        }


class IketPostprocessorV2:
    """
    Postprocessor that loads decoded results directly from iket.decoded_results.json
    generated by IketKernelPatchRecipe::generateTrace API.
    This version skips Activities reconstruction and uses pre-decoded traces directly.

    The current decoded result format uses compact indexed tables:
    ``stringTable`` stores range/marker names and ``locationTable`` stores warp
    locations. Payload fields are omitted when the payload type is kNoPayload.
    """

    def __init__(
        self,
        instrument_config_path: Path,
        decoded_results_path: Path,
        postprocess_dir: Path,
        cubin_json_path: Optional[Path] = None,
    ):
        """
        Initialize the postprocessor with decoded results.

        Args:
            instrument_config_path: Path to instrumentation configuration (for event name mapping)
            decoded_results_path: Path to iket.decoded_results.json
            postprocess_dir: Directory to store output files
            cubin_json_path: Optional path to CUBIN JSON mapping file
        """
        self.instrument_config_path = instrument_config_path
        self.decoded_results_path = decoded_results_path
        self.postprocess_dir = postprocess_dir
        self.cubin_json_path = cubin_json_path

        # Load decoded results
        self.decoded_results = self._load_decoded_results()

        # Load lookup tables (compact format, required for new decoded results).
        self.string_table: List[str] = self.decoded_results.get("stringTable", [])
        self.location_table: List[dict] = self.decoded_results.get("locationTable", [])
        if not self.string_table or not self.location_table:
            iket_print(
                "Warning: decoded_results.json missing stringTable or locationTable. "
                "This may indicate an older C++ injection library was used."
            )

        # Load CUBIN mappings if available
        self.kernel_to_cubin_mapping = self._load_cubin_mappings()

        # Initialize event ID to name mapping
        self.event_id_to_name = self._initialize_event_id_to_name()

    def _load_decoded_results(self):
        """Load the decoded results from JSON file."""
        if _has_orjson:
            with open(self.decoded_results_path, "rb") as f:
                return orjson.loads(f.read())
        with open(self.decoded_results_path, "r") as f:
            return json.load(f)

    def _load_cubin_mappings(self):
        """Load CUBIN ID to real path mappings from JSON file."""
        if not self.cubin_json_path or not self.cubin_json_path.exists():
            return {}

        try:
            with open(self.cubin_json_path, "r") as f:
                cubin_data = json.load(f)

            # Extract module ID to cubin path mappings
            module_to_cubin = {}
            for module in cubin_data.get("modules", []):
                module_id = module.get("moduleId")
                image_path = module.get("image")
                if module_id is not None and image_path:
                    module_to_cubin[module_id] = image_path

            # Create kernel name to cubin path mapping
            kernel_to_cubin_mapping = {}
            for launch in cubin_data.get("launches", []):
                kernel_name = launch.get("kernelName")
                module_id = launch.get("moduleId")
                if kernel_name and module_id in module_to_cubin:
                    kernel_to_cubin_mapping[kernel_name] = module_to_cubin[module_id]

            return kernel_to_cubin_mapping

        except Exception as e:
            iket_print(f"Warning: Could not load cubin JSON file: {e}")
            return {}

    def _initialize_event_id_to_name(self):
        """Initialize event ID to name mapping from CUBIN files."""
        event_id_to_name = defaultdict(dict)  # kname -> {id: name}

        for kernel_name, cubin_path in self.kernel_to_cubin_mapping.items():
            try:
                with open(cubin_path, "rb") as f:
                    cubin_data = f.read()

                context = Context(cubin_data)
                if context.is_instrumented():
                    all_events = context.get_all_events()
                    for event in all_events:
                        event_id_to_name[kernel_name][event.event_id] = event.event_name
            except Exception as e:
                iket_print(f"Warning: Could not create context for {kernel_name}: {e}")

        return event_id_to_name

    def _resolve_string(self, idx: int) -> str:
        """Resolve a string table index with bounds checking."""
        if idx < 0 or idx >= len(self.string_table):
            raise ValueError(
                f"String table index {idx} out of range (table size: {len(self.string_table)})"
            )
        return self.string_table[idx]

    def _resolve_location(self, idx: int) -> dict:
        """Resolve a location table index with bounds checking."""
        if idx < 0 or idx >= len(self.location_table):
            raise ValueError(
                f"Location table index {idx} out of range (table size: {len(self.location_table)})"
            )
        return self.location_table[idx]

    def _resolve_range_name(self, range_data: dict) -> str:
        """Resolve range name from compact or legacy decoded results."""
        if "rangeNameIdx" in range_data:
            return self._resolve_string(range_data["rangeNameIdx"])
        return range_data["rangeName"]

    def _resolve_marker_name(self, marker_data: dict) -> str:
        """Resolve marker name from compact or legacy decoded results."""
        if "markerNameIdx" in marker_data:
            return self._resolve_string(marker_data["markerNameIdx"])
        return marker_data["markerName"]

    def _resolve_marker_location(self, marker_data: dict) -> dict:
        """Resolve marker location from compact or legacy decoded results."""
        if "locIdx" in marker_data:
            return self._resolve_location(marker_data["locIdx"])
        return marker_data["location"]

    def _resolve_warp_lifetime_location(self, wl_data: dict) -> dict:
        """Resolve warp lifetime location from compact or legacy decoded results."""
        if "locIdx" in wl_data:
            return self._resolve_location(wl_data["locIdx"])
        return wl_data["warpLocation"]

    def _resolve_warp_locs(self, range_data: dict) -> list:
        """Resolve range warp locations from compact or legacy decoded results."""
        if "warpLocIdxs" in range_data:
            return [self._resolve_location(idx) for idx in range_data["warpLocIdxs"]]
        return range_data["warpLocs"]

    @staticmethod
    def _get_payload_type(data: dict) -> int:
        """Get payloadType from data dict, defaulting to kNoPayload if absent."""
        return data.get("payloadType", 0)

    @staticmethod
    def _get_payload_val(data: dict) -> int:
        """Get payloadVal from data dict, defaulting to 0 if absent."""
        return data.get("payloadVal", 0)

    def _parse_location_from_json(self, loc_json):
        """Parse EventLocation from JSON."""
        return EventLocation(
            sm_id=loc_json["smId"],
            tpc_id=loc_json["tpcId"],
            gpc_id=loc_json["gpcId"],
            cluster_id=tuple(loc_json.get("clusterId", (-1, -1, -1))),
            cta_id=tuple(loc_json["ctaId"]),
            warp_id=loc_json["warpId"],
        )

    def dump_perfetto(self, output_path: Path) -> bytes:
        """Generate perfetto trace directly from decoded results.
        Returns the serialized trace bytes for reuse by dump_perfetto_html.
        """
        perfetto_trace = self._make_perfetto_trace_from_decoded_results()
        trace_bytes = perfetto_trace.SerializeToString()
        with open(output_path, "wb") as f:
            f.write(trace_bytes)
        iket_print(f"Dumped perfetto trace to {output_path}")
        return trace_bytes

    def dump_perfetto_html(
        self, output_path: Path, trace_bytes: Optional[bytes] = None
    ):
        """Generate an HTML viewer + companion .pftrace.gz file.
        The HTML fetches the .gz file via relative URL and loads it into Perfetto UI.
        If trace_bytes is provided, reuses them instead of regenerating the trace.
        """
        if trace_bytes is None:
            perfetto_trace = self._make_perfetto_trace_from_decoded_results()
            trace_bytes = perfetto_trace.SerializeToString()

        # Write compressed trace as a separate .pftrace.gz file
        gz_filename = output_path.stem + ".pftrace.gz"
        gz_path = output_path.parent / gz_filename
        compressed = gzip.compress(trace_bytes)
        with open(gz_path, "wb") as f:
            f.write(compressed)
        iket_print(f"Dumped compressed trace to {gz_path}")

        # Write small HTML viewer that fetches the .gz file
        title = output_path.stem
        html = _PERFETTO_HTML_TEMPLATE.replace("{{TRACE_URL}}", gz_filename).replace(
            "{{TITLE}}", title
        )
        with open(output_path, "w") as f:
            f.write(html)
        iket_print(f"Dumped perfetto HTML viewer to {output_path}")

        # Print viewing instructions
        output_str = str(output_path.resolve())
        output_dir = str(output_path.resolve().parent)
        html_filename = output_path.name
        browser_url = None
        if not EXTERNAL_RELEASE:
            from ._viewer_url_internal import get_internal_viewer_url

            browser_url = get_internal_viewer_url(output_str)
        if browser_url:
            iket_print(f"View in browser: {browser_url}")
        else:
            iket_print(
                f"To view: cd {output_dir} && python3 -m http.server 8080"
                f" , then open http://localhost:8080/{html_filename}"
            )

    def _make_track_event_packet(self, timestamp, event_type, name, track_uuid):
        packet = TracePacket()
        packet.timestamp = timestamp
        packet.trusted_packet_sequence_id = 1
        event = packet.track_event
        event.type = event_type
        event.name = name
        event.track_uuid = track_uuid
        return packet

    def _make_perfetto_trace_from_decoded_results(self):
        """Convert decoded results to perfetto format."""
        # Create perfetto trace
        trace = Trace()
        counter = itertools.count(start=1, step=1)
        event_buffer = _PerfettoTrackEventBuffer()

        # Create root track
        root_track = trace.packet.add()
        root_track.track_descriptor.uuid = next(counter)
        root_track.track_descriptor.name = "Root"
        root_track.track_descriptor.child_ordering = TrackDescriptor.EXPLICIT
        root_uuid = root_track.track_descriptor.uuid

        # Detect multi-context: collect unique context IDs from all launches and graph launches
        all_launch_results = self.decoded_results.get("launches", [])
        graph_launch_results = self.decoded_results.get("graphLaunches", {})
        all_context_sources = list(all_launch_results)
        for results in graph_launch_results.values():
            all_context_sources.extend(results)
        context_ids = sorted(set(r.get("contextId", 0) for r in all_context_sources))
        multi_context = len(context_ids) > 1

        # Context tracks: only created when multiple contexts exist
        context_tracks = {}
        if multi_context:
            for ctx_id in context_ids:
                ctx_track = trace.packet.add()
                ctx_track.track_descriptor.uuid = next(counter)
                ctx_track.track_descriptor.name = f"GPU/Context {ctx_id}"
                ctx_track.track_descriptor.parent_uuid = root_uuid
                ctx_track.track_descriptor.sibling_order_rank = ctx_id
                ctx_track.track_descriptor.child_ordering = TrackDescriptor.EXPLICIT
                context_tracks[ctx_id] = ctx_track.track_descriptor.uuid

        # Track hierarchy: [Context ->] Grid -> GPC -> TPC|VSM -> CTA -> Warp -> event tracks
        graph_tracks = {}
        grid_tracks = {}
        gpc_tracks = {}
        tpc_tracks = {}
        cta_tracks = {}
        warp_tracks = {}
        warp_child_tracks = {}
        warp_start_end_tracks = {}
        warp_start_end_counts = {}

        def get_kernel_time_range(result: dict):
            warp_lifetimes = result.get("warpLifetimes", [])
            if warp_lifetimes:
                return (
                    min(w["startTs"] for w in warp_lifetimes),
                    max(w["endTs"] for w in warp_lifetimes),
                )
            ranges = result.get("ranges", [])
            if ranges:
                return (
                    min(r["startTs"] for r in ranges),
                    max(r["endTs"] for r in ranges),
                )
            return None

        def get_graph_launch_display_name(graph_launch_key: str):
            if graph_launch_key.startswith("graph_exec_") and ":" in graph_launch_key:
                graph_exec_id, graph_launch_id = graph_launch_key[
                    len("graph_exec_") :
                ].split(":", 1)
                return f"GraphExec{graph_exec_id} Launch{graph_launch_id}"
            return graph_launch_key

        def get_compact_kernel_name(kernel_name: str):
            if len(kernel_name) <= 80:
                return kernel_name
            return f"{kernel_name[:56]}...{kernel_name[-20:]}"

        def ensure_graph_launch_track(
            graph_launch_key: str,
            context_id: int,
            sibling_order_rank: Optional[int],
        ):
            graph_parent_uuid = (
                context_tracks[context_id] if multi_context else root_uuid
            )
            if graph_launch_key not in graph_tracks:
                graph_track = trace.packet.add()
                graph_track.track_descriptor.uuid = next(counter)
                graph_track.track_descriptor.name = get_graph_launch_display_name(
                    graph_launch_key
                )
                graph_track.track_descriptor.parent_uuid = graph_parent_uuid
                if sibling_order_rank is not None:
                    graph_track.track_descriptor.sibling_order_rank = sibling_order_rank
                graph_track.track_descriptor.child_ordering = TrackDescriptor.EXPLICIT
                graph_tracks[graph_launch_key] = graph_track.track_descriptor.uuid
            return graph_tracks[graph_launch_key]

        def add_launch_result_to_trace(
            result: dict,
            display_name: str,
            display_grid_id: int,
            n_total_launches: int,
            launch_key: Optional[str] = None,
            track_name: Optional[str] = None,
            parent_uuid: Optional[int] = None,
            sibling_order_rank: Optional[int] = None,
        ):
            grid_id = result["gridId"]
            context_id = result["contextId"]
            kernel_time_range = get_kernel_time_range(result)
            if kernel_time_range is None:
                return
            kernel_start, kernel_end = kernel_time_range

            if launch_key is None:
                launch_key = f"Context:{context_id},Grid:{grid_id}"

            # In multi-context mode, grid tracks are children of context tracks
            if parent_uuid is None:
                parent_uuid = context_tracks[context_id] if multi_context else root_uuid

            # Ensure grid track exists
            self._ensure_grid_track(
                trace,
                counter,
                grid_tracks,
                launch_key,
                display_grid_id,
                n_total_launches,
                parent_uuid=parent_uuid,
                track_name=track_name,
                sibling_order_rank=sibling_order_rank,
            )

            # Add kernel lifetime
            kernel_name = f"kernel:{display_name}, gridId: {grid_id}"
            kernel_begin_packet = self._make_track_event_packet(
                kernel_start,
                TrackEvent.TYPE_SLICE_BEGIN,
                kernel_name,
                grid_tracks[launch_key],
            )
            kernel_end_packet = self._make_track_event_packet(
                kernel_end,
                TrackEvent.TYPE_SLICE_END,
                kernel_name,
                grid_tracks[launch_key],
            )
            event_buffer.add_slice(kernel_begin_packet, kernel_end_packet)

            # Process ranges
            for range_data in result.get("ranges", []):
                self._add_range_to_trace(
                    trace,
                    counter,
                    grid_tracks,
                    gpc_tracks,
                    tpc_tracks,
                    cta_tracks,
                    warp_tracks,
                    warp_child_tracks,
                    warp_start_end_tracks,
                    warp_start_end_counts,
                    event_buffer,
                    range_data,
                    launch_key,
                    display_name,
                )

            # Process warp lifetimes
            for warp_lifetime in result.get("warpLifetimes", []):
                warp_loc = self._resolve_warp_lifetime_location(warp_lifetime)
                warp_key = self._ensure_track_hierarchy(
                    trace,
                    counter,
                    grid_tracks,
                    gpc_tracks,
                    tpc_tracks,
                    cta_tracks,
                    warp_tracks,
                    warp_loc,
                    launch_key,
                )

                # Add warp lifetime slice
                warp_begin_packet = self._make_track_event_packet(
                    warp_lifetime["startTs"],
                    TrackEvent.TYPE_SLICE_BEGIN,
                    "Warp Life Time",
                    warp_tracks[warp_key],
                )
                warp_end_packet = self._make_track_event_packet(
                    warp_lifetime["endTs"],
                    TrackEvent.TYPE_SLICE_END,
                    "Warp Life Time",
                    warp_tracks[warp_key],
                )
                event_buffer.add_slice(warp_begin_packet, warp_end_packet)

            # Process markers
            for marker_data in result.get("markers", []):
                self._add_marker_to_trace(
                    trace,
                    marker_data,
                    counter,
                    grid_tracks,
                    gpc_tracks,
                    tpc_tracks,
                    cta_tracks,
                    warp_tracks,
                    warp_child_tracks,
                    event_buffer,
                    launch_key,
                )

        launch_results: list = self.decoded_results["launches"]
        graph_launch_results: dict[str, list] = self.decoded_results.get(
            "graphLaunches", {}
        )
        graph_time_ranges_by_key = {
            graph_launch_key: [
                time_range
                for time_range in (get_kernel_time_range(result) for result in results)
                if time_range is not None
            ]
            for graph_launch_key, results in graph_launch_results.items()
        }

        top_level_order_entries = []
        for launch_index, result in enumerate(launch_results):
            time_range = get_kernel_time_range(result)
            if time_range is not None:
                top_level_order_entries.append(
                    (
                        time_range[0],
                        len(top_level_order_entries),
                        ("launch", launch_index),
                    )
                )
        for graph_launch_key, graph_time_ranges in graph_time_ranges_by_key.items():
            if graph_time_ranges:
                top_level_order_entries.append(
                    (
                        min(start for start, _ in graph_time_ranges),
                        len(top_level_order_entries),
                        ("graph", graph_launch_key),
                    )
                )
        top_level_order = {
            top_level_key: rank
            for rank, (_, _, top_level_key) in enumerate(
                sorted(top_level_order_entries)
            )
        }

        # Collect all launches (regular + graph) for chronological grid numbering
        all_launches = []
        for launch_index, result in enumerate(launch_results):
            display_name = result["kernelName"]
            all_launches.append(
                {
                    "result": result,
                    "display_name": display_name,
                    "launch_key": None,
                    "track_name": None,
                    "parent_uuid": None,
                    "sibling_order_rank": top_level_order.get(("launch", launch_index)),
                }
            )

        for graph_launch_key, results in graph_launch_results.items():
            graph_time_ranges = graph_time_ranges_by_key[graph_launch_key]
            if graph_time_ranges:
                context_id = results[0].get("contextId", 0)
                graph_track_uuid = ensure_graph_launch_track(
                    graph_launch_key,
                    context_id,
                    top_level_order.get(("graph", graph_launch_key)),
                )
                graph_display_name = get_graph_launch_display_name(graph_launch_key)
                graph_begin_packet = self._make_track_event_packet(
                    min(start for start, _ in graph_time_ranges),
                    TrackEvent.TYPE_SLICE_BEGIN,
                    graph_display_name,
                    graph_track_uuid,
                )
                graph_end_packet = self._make_track_event_packet(
                    max(end for _, end in graph_time_ranges),
                    TrackEvent.TYPE_SLICE_END,
                    graph_display_name,
                    graph_track_uuid,
                )
                event_buffer.add_slice(graph_begin_packet, graph_end_packet)

            sorted_results = sorted(results, key=lambda x: x["gridId"])
            for node_index, result in enumerate(sorted_results):
                kernel_name = result["kernelName"]
                compact_kernel_name = get_compact_kernel_name(kernel_name)
                grid_id = result["gridId"]
                all_launches.append(
                    {
                        "result": result,
                        "display_name": (
                            f"{get_graph_launch_display_name(graph_launch_key)} "
                            f"Node{node_index}: {kernel_name}"
                        ),
                        "launch_key": (
                            f"Context:{result['contextId']},"
                            f"Graph:{graph_launch_key},"
                            f"Node:{node_index},Grid:{grid_id}"
                        ),
                        "track_name": (
                            f"Node{node_index}: {compact_kernel_name}, "
                            f"gridId: {grid_id}"
                        ),
                        "parent_uuid": graph_tracks.get(graph_launch_key),
                        "sibling_order_rank": node_index,
                    }
                )

        # Sort by earliest timestamp to assign grid indices in chronological order
        def get_earliest_ts(result):
            warp_lifetimes = result.get("warpLifetimes", [])
            if warp_lifetimes:
                return min(w["startTs"] for w in warp_lifetimes)
            ranges = result.get("ranges", [])
            if ranges:
                return min(r["startTs"] for r in ranges)
            return float("inf")

        all_launches.sort(key=lambda x: get_earliest_ts(x["result"]))

        n_total = len(all_launches)
        for display_grid_id, launch in enumerate(all_launches, start=1):
            add_launch_result_to_trace(
                launch["result"],
                launch["display_name"],
                display_grid_id,
                n_total,
                launch_key=launch["launch_key"],
                track_name=launch["track_name"],
                parent_uuid=launch["parent_uuid"],
                sibling_order_rank=launch["sibling_order_rank"],
            )

        event_buffer.flush_to_trace(trace)
        return trace

    def _ensure_grid_track(
        self,
        trace,
        counter,
        grid_tracks,
        launch_key,
        display_grid_id,
        n_launches,
        parent_uuid=None,
        track_name=None,
        sibling_order_rank=None,
    ):
        """
        Ensure grid track exists. Add new grid track to the trace if not exists.
        parent_uuid: UUID of the parent track. Defaults to root track if not provided.
        """
        n_digits = len(str(n_launches))
        if launch_key not in grid_tracks:
            if parent_uuid is None:
                parent_uuid = trace.packet[0].track_descriptor.uuid
            grid_track = trace.packet.add()
            grid_track.track_descriptor.uuid = next(counter)
            grid_track.track_descriptor.name = (
                track_name or f"Grid{display_grid_id:0{n_digits}d}"
            )
            grid_track.track_descriptor.parent_uuid = parent_uuid
            grid_track.track_descriptor.sibling_order_rank = (
                sibling_order_rank
                if sibling_order_rank is not None
                else 1000000000 + display_grid_id
            )
            grid_track.track_descriptor.child_ordering = TrackDescriptor.LEXICOGRAPHIC
            grid_tracks[launch_key] = grid_track.track_descriptor.uuid

    def _ensure_track_hierarchy(
        self,
        trace,
        counter,
        grid_tracks,
        gpc_tracks,
        tpc_tracks,
        cta_tracks,
        warp_tracks,
        warp_loc,
        kernel_key,
    ):
        """
        Ensure the track hierarchy exists for the given warp_loc. Add new track to the trace if not exists.
        """
        if isinstance(warp_loc, dict):
            gpc_id = warp_loc["gpcId"]
            tpc_id = warp_loc["tpcId"]
            sm_id = warp_loc["smId"]
            cta_id = tuple(warp_loc["ctaId"])
            warp_id = warp_loc["warpId"]
        else:
            gpc_id = warp_loc.gpc_id
            tpc_id = warp_loc.tpc_id
            sm_id = warp_loc.sm_id
            cta_id = warp_loc.cta_id
            warp_id = warp_loc.warp_id

        gpc_key = (kernel_key, gpc_id)
        if gpc_key not in gpc_tracks:
            gpc_track = trace.packet.add()
            gpc_track.track_descriptor.uuid = next(counter)
            gpc_track.track_descriptor.name = (
                f"GPC{gpc_id}" if gpc_id != -1 else "GPC(ID not available)"
            )
            gpc_track.track_descriptor.parent_uuid = grid_tracks[kernel_key]
            gpc_track.track_descriptor.child_ordering = TrackDescriptor.LEXICOGRAPHIC
            gpc_tracks[gpc_key] = gpc_track.track_descriptor.uuid

        tpc_key = (gpc_key, tpc_id, sm_id)
        if tpc_key not in tpc_tracks:
            tpc_track = trace.packet.add()
            tpc_track.track_descriptor.uuid = next(counter)
            tpc_name = f"TPC{tpc_id}" if tpc_id != -1 else "TPC(ID not available)"
            vsm_name = f"VSM{sm_id}" if sm_id != -1 else "VSM(ID not available)"
            tpc_track.track_descriptor.name = f"{tpc_name}|{vsm_name}"
            tpc_track.track_descriptor.parent_uuid = gpc_tracks[gpc_key]
            tpc_track.track_descriptor.child_ordering = TrackDescriptor.EXPLICIT
            tpc_tracks[tpc_key] = tpc_track.track_descriptor.uuid

        cta_key = (tpc_key, cta_id)
        if cta_key not in cta_tracks:
            cta_track = trace.packet.add()
            cta_track.track_descriptor.uuid = next(counter)
            cta_track.track_descriptor.name = f"CTA{cta_id}"
            cta_track.track_descriptor.parent_uuid = tpc_tracks[tpc_key]
            cta_track.track_descriptor.child_ordering = TrackDescriptor.EXPLICIT
            cta_tracks[cta_key] = cta_track.track_descriptor.uuid

        warp_key = (cta_key, warp_id)
        if warp_key not in warp_tracks:
            warp_track = trace.packet.add()
            warp_track.track_descriptor.uuid = next(counter)
            warp_track.track_descriptor.name = f"Warp{warp_id:02d}"
            warp_track.track_descriptor.parent_uuid = cta_tracks[cta_key]
            warp_track.track_descriptor.sibling_order_rank = max(warp_id, 0)
            warp_track.track_descriptor.child_ordering = TrackDescriptor.EXPLICIT
            warp_tracks[warp_key] = warp_track.track_descriptor.uuid

        return warp_key

    def _get_warp_child_track(
        self,
        trace,
        counter,
        warp_tracks,
        warp_child_tracks,
        warp_key,
        child_name,
    ):
        track_key = (warp_key, child_name)
        if track_key not in warp_child_tracks:
            child_track = trace.packet.add()
            child_track.track_descriptor.uuid = next(counter)
            child_track.track_descriptor.name = child_name
            child_track.track_descriptor.parent_uuid = warp_tracks[warp_key]
            child_track.track_descriptor.sibling_order_rank = _WARP_TRACK_KIND_ORDER[
                child_name
            ]
            child_track.track_descriptor.child_ordering = TrackDescriptor.LEXICOGRAPHIC
            warp_child_tracks[track_key] = child_track.track_descriptor.uuid

        return warp_child_tracks[track_key]

    def _get_warp_start_end_track(
        self,
        trace,
        counter,
        warp_tracks,
        warp_start_end_tracks,
        warp_start_end_counts,
        warp_key,
        range_name: str,
    ):
        track_key = (warp_key, range_name)
        if track_key not in warp_start_end_tracks:
            start_end_index = warp_start_end_counts.get(warp_key, 0)
            warp_start_end_counts[warp_key] = start_end_index + 1
            track = trace.packet.add()
            track.track_descriptor.uuid = next(counter)
            track.track_descriptor.name = range_name
            track.track_descriptor.parent_uuid = warp_tracks[warp_key]
            track.track_descriptor.sibling_order_rank = (
                _WARP_TRACK_KIND_ORDER["StartEnd"] + start_end_index
            )
            track.track_descriptor.child_ordering = TrackDescriptor.LEXICOGRAPHIC
            warp_start_end_tracks[track_key] = track.track_descriptor.uuid
        return warp_start_end_tracks[track_key]

    def _get_warp_key(self, warp_loc, kernel_key):
        """Get warp key tuple for track lookup."""
        if isinstance(warp_loc, dict):
            gpc_id = warp_loc["gpcId"]
            tpc_id = warp_loc["tpcId"]
            sm_id = warp_loc["smId"]
            cta_id = tuple(warp_loc["ctaId"])
            warp_id = warp_loc["warpId"]
        else:
            gpc_id = warp_loc.gpc_id
            tpc_id = warp_loc.tpc_id
            sm_id = warp_loc.sm_id
            cta_id = warp_loc.cta_id
            warp_id = warp_loc.warp_id
        gpc_key = (kernel_key, gpc_id)
        tpc_key = (gpc_key, tpc_id, sm_id)
        cta_key = (tpc_key, cta_id)
        return (cta_key, warp_id)

    def _make_flow_id(self, *parts):
        return hash(":".join(str(part) for part in parts)) & 0xFFFFFFFFFFFFFFFF

    def _add_marker_to_trace(
        self,
        trace,
        marker_data,
        counter,
        grid_tracks,
        gpc_tracks,
        tpc_tracks,
        cta_tracks,
        warp_tracks,
        warp_child_tracks,
        event_buffer,
        kernel_key,
        marker_loc=None,
        marker_name=None,
    ):
        """
        Add a marker to the perfetto trace.
        Args:
            trace: Perfetto trace object.
            marker_data: Marker data dictionary.
            marker_loc: Marker location. If not provided, it will be resolved from marker_data.
            marker_name: Marker name. If not provided, it will be marker_data["markerName"].
        """
        if marker_loc is None:
            marker_loc = self._resolve_marker_location(marker_data)
        warp_key = self._ensure_track_hierarchy(
            trace,
            counter,
            grid_tracks,
            gpc_tracks,
            tpc_tracks,
            cta_tracks,
            warp_tracks,
            marker_loc,
            kernel_key,
        )
        if marker_name is None:
            marker_name = self._resolve_marker_name(marker_data)
        marker_track_uuid = self._get_warp_child_track(
            trace,
            counter,
            warp_tracks,
            warp_child_tracks,
            warp_key,
            "Marker",
        )
        marker_packet = self._make_track_event_packet(
            marker_data["timestamp"],
            TrackEvent.TYPE_INSTANT,
            self._format_marker_name_with_payload(
                marker_name,
                self._get_payload_type(marker_data),
                self._get_payload_val(marker_data),
            ),
            marker_track_uuid,
        )
        marker_event = marker_packet.track_event
        self._set_payload_annotations(
            marker_event,
            self._get_payload_type(marker_data),
            self._get_payload_val(marker_data),
        )
        event_buffer.add_instant(marker_packet)

    def _add_range_to_trace(
        self,
        trace,
        counter,
        grid_tracks,
        gpc_tracks,
        tpc_tracks,
        cta_tracks,
        warp_tracks,
        warp_child_tracks,
        warp_start_end_tracks,
        warp_start_end_counts,
        event_buffer,
        range_data,
        kernel_key,
        kernel_name,
    ):
        """Add a range to the perfetto trace."""
        # Warp locations are all event locations of the range. Use raw dicts for
        # compact decoded results to avoid constructing EventLocation per event.
        warp_locs_raw = self._resolve_warp_locs(range_data)
        if not warp_locs_raw:
            return

        range_scope_int = range_data["rangeScope"]
        range_name = self._resolve_range_name(range_data)

        if range_scope_int == _RANGE_SCOPE_INTRA_WARP:
            # Intra-warp range
            # use first warp location as the warp location for the range
            warp_loc = warp_locs_raw[0]
            warp_key = self._ensure_track_hierarchy(
                trace,
                counter,
                grid_tracks,
                gpc_tracks,
                tpc_tracks,
                cta_tracks,
                warp_tracks,
                warp_loc,
                kernel_key,
            )
            range_type = RangeType(range_data["rangeType"])
            if range_type == RangeType.PUSH_POP:
                range_track_uuid = self._get_warp_child_track(
                    trace,
                    counter,
                    warp_tracks,
                    warp_child_tracks,
                    warp_key,
                    "StackedRanges",
                )
            elif range_type == RangeType.START_END:
                range_track_uuid = self._get_warp_start_end_track(
                    trace,
                    counter,
                    warp_tracks,
                    warp_start_end_tracks,
                    warp_start_end_counts,
                    warp_key,
                    range_name,
                )
            else:
                return

            internal_events = range_data["internalEvents"]

            formatted_range_name = self._format_range_name_with_payload(
                range_name, internal_events
            )
            if range_data["endTs"] == range_data["startTs"]:
                formatted_range_name += " [duration=0]"
            range_begin_packet = self._make_track_event_packet(
                range_data["startTs"],
                TrackEvent.TYPE_SLICE_BEGIN,
                formatted_range_name,
                range_track_uuid,
            )
            range_begin_event = range_begin_packet.track_event
            # Add payload from the start event (first internalEvent)
            if internal_events:
                self._set_payload_annotations(
                    range_begin_event,
                    self._get_payload_type(internal_events[0]),
                    self._get_payload_val(internal_events[0]),
                )

            range_end_packet = self._make_track_event_packet(
                range_data["endTs"],
                TrackEvent.TYPE_SLICE_END,
                formatted_range_name,
                range_track_uuid,
            )
            range_end_event = range_end_packet.track_event
            # Add payload from the end event (last internalEvent)
            if len(internal_events) >= 2:
                self._set_payload_annotations(
                    range_end_event,
                    self._get_payload_type(internal_events[-1]),
                    self._get_payload_val(internal_events[-1]),
                )
            event_buffer.add_slice(range_begin_packet, range_end_packet)

            # Only draw truly internal events (not the start/end boundary events)
            # as markers inside the range
            start_ts = range_data["startTs"]
            end_ts = range_data["endTs"]
            for i, event in enumerate(internal_events):
                if event["timestamp"] == start_ts or event["timestamp"] == end_ts:
                    continue  # skip boundary events, already represented by the slice
                self._add_marker_to_trace(
                    trace,
                    event,
                    counter,
                    grid_tracks,
                    gpc_tracks,
                    tpc_tracks,
                    cta_tracks,
                    warp_tracks,
                    warp_child_tracks,
                    event_buffer,
                    kernel_key,
                    marker_loc=warp_locs_raw[i],
                    marker_name=range_name,
                )
        else:
            # Cross-warp range - add markers and slices
            internal_events = range_data["internalEvents"]
            kernel_event_names = self.event_id_to_name.get(kernel_name, {})

            # Add markers for each event
            warp_keys = []
            for i, event in enumerate(internal_events):
                warp_loc = warp_locs_raw[i]
                warp_key = self._ensure_track_hierarchy(
                    trace,
                    counter,
                    grid_tracks,
                    gpc_tracks,
                    tpc_tracks,
                    cta_tracks,
                    warp_tracks,
                    warp_loc,
                    kernel_key,
                )
                warp_keys.append(warp_key)
                marker_track_uuid = self._get_warp_child_track(
                    trace,
                    counter,
                    warp_tracks,
                    warp_child_tracks,
                    warp_key,
                    "Marker",
                )

                # Get event name
                event_id = event["eventId"]
                event_name = kernel_event_names.get(event_id, f"Event{event_id}")

                marker_packet = self._make_track_event_packet(
                    event["timestamp"],
                    TrackEvent.TYPE_INSTANT,
                    f"{range_name}:{event_name}",
                    marker_track_uuid,
                )
                marker_event = marker_packet.track_event

                # Add flow IDs for linking
                marker_event.flow_ids.append(
                    self._make_flow_id(warp_key, "marker", event["timestamp"])
                )

                if i < len(internal_events) - 1:
                    next_event = internal_events[i + 1]
                    next_warp_key = self._get_warp_key(warp_locs_raw[i + 1], kernel_key)
                    marker_event.flow_ids.append(
                        self._make_flow_id(
                            next_warp_key, "marker", next_event["timestamp"]
                        )
                    )
                    marker_event.flow_ids.append(
                        self._make_flow_id(warp_key, "segment", event["timestamp"])
                    )
                event_buffer.add_instant(marker_packet)

            # Determine parent track based on scope
            if not warp_keys:
                return
            first_warp_key = warp_keys[0]
            cta_key = first_warp_key[0]
            tpc_key = cta_key[0]
            gpc_key = tpc_key[0]
            if range_scope_int == _RANGE_SCOPE_INTER_WARP_IN_CTA:
                parent_uuid = cta_tracks[cta_key]
            elif range_scope_int == _RANGE_SCOPE_INTER_WARP_IN_SM:
                parent_uuid = tpc_tracks[tpc_key]
            elif range_scope_int == _RANGE_SCOPE_INTER_WARP_IN_TPC:
                first_loc = warp_locs_raw[0]
                same_tpc_vsm = all(
                    loc["gpcId"] == first_loc["gpcId"]
                    and loc["tpcId"] == first_loc["tpcId"]
                    and loc["smId"] == first_loc["smId"]
                    for loc in warp_locs_raw
                )
                parent_uuid = (
                    tpc_tracks[tpc_key] if same_tpc_vsm else gpc_tracks[gpc_key]
                )
            elif range_scope_int == _RANGE_SCOPE_INTER_WARP_IN_GPC:
                parent_uuid = gpc_tracks[gpc_key]
            else:
                return

            uuid = parent_uuid

            # Add slices between consecutive events
            for i in range(len(internal_events) - 1):
                start_event = internal_events[i]
                end_event = internal_events[i + 1]
                start_warp_loc = warp_locs_raw[i]
                end_warp_loc = warp_locs_raw[i + 1]

                start_event_name = kernel_event_names.get(
                    start_event["eventId"], f"Event{start_event['eventId']}"
                )
                end_event_name = kernel_event_names.get(
                    end_event["eventId"], f"Event{end_event['eventId']}"
                )

                range_begin_packet = self._make_track_event_packet(
                    start_event["timestamp"],
                    TrackEvent.TYPE_SLICE_BEGIN,
                    f"{range_name}: {start_event_name}(warp {start_warp_loc['warpId']}) -> {end_event_name}(warp {end_warp_loc['warpId']})",
                    uuid,
                )
                range_begin_event = range_begin_packet.track_event

                range_end_packet = self._make_track_event_packet(
                    end_event["timestamp"],
                    TrackEvent.TYPE_SLICE_END,
                    range_name,
                    uuid,
                )

                warp_key = warp_keys[i]
                range_begin_event.flow_ids.append(
                    self._make_flow_id(warp_key, "segment", start_event["timestamp"])
                )
                event_buffer.add_slice(range_begin_packet, range_end_packet)

    def dump_json(self, output_path: Path):
        """Dump decoded results as JSON in compact indexed format.

        Since the output is identical to the input decoded_results.json,
        this simply copies the file for maximum performance.
        """
        import shutil

        shutil.copy2(self.decoded_results_path, output_path)
        iket_print(f"Dumped json trace to {output_path}")

    def _format_payload_val(self, val):
        """Format a parsed payload value for display."""
        if val is None:
            return None
        if isinstance(val, float):
            return f"{val:g}"
        return str(val)

    def _format_marker_name_with_payload(self, marker_name, payload_type, payload_val):
        """Format marker name to include payload value if present."""
        pt_int = (
            payload_type if isinstance(payload_type, int) else _enum_int(payload_type)
        )
        if pt_int == _PAYLOAD_TYPE_NO_PAYLOAD:
            return marker_name
        val = self._format_payload_val(
            self._parse_payload_value_int(payload_val, pt_int)
        )
        return f"{marker_name}(payload={val})"

    def _format_range_name_with_payload(self, range_name, internal_events):
        """Format range name to include payload values if present."""
        if not internal_events:
            return range_name

        start_event = internal_events[0]
        start_type_int = self._get_payload_type(start_event)
        start_has_payload = start_type_int != _PAYLOAD_TYPE_NO_PAYLOAD

        end_has_payload = False
        end_event = None
        if len(internal_events) >= 2:
            end_event = internal_events[-1]
            end_type_int = self._get_payload_type(end_event)
            end_has_payload = end_type_int != _PAYLOAD_TYPE_NO_PAYLOAD

        if start_has_payload and end_has_payload:
            start_val = self._format_payload_val(
                self._parse_payload_value_int(
                    self._get_payload_val(start_event), start_type_int
                )
            )
            end_val = self._format_payload_val(
                self._parse_payload_value_int(
                    self._get_payload_val(end_event), end_type_int
                )
            )
            return f"{range_name}(start_payload={start_val}, end_payload={end_val})"
        elif start_has_payload:
            start_val = self._format_payload_val(
                self._parse_payload_value_int(
                    self._get_payload_val(start_event), start_type_int
                )
            )
            return f"{range_name}(payload={start_val})"
        elif end_has_payload:
            end_val = self._format_payload_val(
                self._parse_payload_value_int(
                    self._get_payload_val(end_event), end_type_int
                )
            )
            return f"{range_name}(end_payload={end_val})"
        else:
            return range_name

    def _set_payload_annotations(self, marker_event, payload_type_int, payload_val):
        """
        Fast path to set payload_type and payload_val debug annotations.

        Accepts raw int payload_type (as from JSON) to avoid enum construction overhead.
        Skips annotation creation entirely for kNoPayload (the common case).
        """
        if payload_type_int == _PAYLOAD_TYPE_NO_PAYLOAD:
            return

        type_str = _PAYLOAD_TYPE_STR_BY_INT.get(
            payload_type_int, f"Unknown({payload_type_int})"
        )
        annotation = marker_event.debug_annotations.add()
        annotation.name = "payload_type"
        annotation.string_value = type_str

        parsed_val = self._parse_payload_value_int(payload_val, payload_type_int)
        if parsed_val is not None:
            annotation = marker_event.debug_annotations.add()
            annotation.name = "payload_val"
            if isinstance(parsed_val, float):
                annotation.double_value = parsed_val
            else:
                annotation.int_value = parsed_val

    def set_payload_type_and_val(self, marker_event, payload_type, payload_val):
        """
        Helper to set payload_type and payload_val debug annotations on a Perfetto marker_event.

        Args:
            marker_event: Perfetto TrackEvent proto message.
            payload_type: int or IketEvtPayloadType value.
            payload_val: int (raw) value.
        """
        if isinstance(payload_type, int):
            return self._set_payload_annotations(
                marker_event, payload_type, payload_val
            )
        return self._set_payload_annotations(
            marker_event, _enum_int(payload_type), payload_val
        )

    def _parse_payload_value_int(
        self, payload_val: int, payload_type_int: int
    ) -> Union[None, int, float]:
        """Fast path for parse_payload_value that accepts raw int type."""
        if payload_type_int == _PAYLOAD_TYPE_NO_PAYLOAD:
            return None

        if payload_type_int == _PT_INT.get("kI8"):
            return struct.unpack("b", struct.pack("B", payload_val & 0xFF))[0]
        elif payload_type_int == _PT_INT.get("kUI8"):
            return payload_val & 0xFF
        elif payload_type_int == _PT_INT.get("kI16"):
            return struct.unpack("<h", struct.pack("<H", payload_val & 0xFFFF))[0]
        elif payload_type_int == _PT_INT.get("kUI16"):
            return payload_val & 0xFFFF
        elif payload_type_int == _PT_INT.get("kI32"):
            return struct.unpack("<i", struct.pack("<I", payload_val & 0xFFFFFFFF))[0]
        elif payload_type_int == _PT_INT.get("kUI32"):
            return payload_val & 0xFFFFFFFF
        elif payload_type_int == _PT_INT.get("kFP4"):
            return payload_val & 0xF
        elif payload_type_int == _PT_INT.get("kFP8"):
            return payload_val & 0xFF
        elif payload_type_int == _PT_INT.get("kFP16"):
            return _fp16_bits_to_float(payload_val & 0xFFFF)
        elif payload_type_int == _PT_INT.get("kBF16"):
            bits = (payload_val & 0xFFFF) << 16
            return struct.unpack("<f", struct.pack("<I", bits))[0]
        elif payload_type_int == _PT_INT.get("kFP32"):
            return struct.unpack("<f", struct.pack("<I", payload_val & 0xFFFFFFFF))[0]
        elif payload_type_int == _PT_INT.get("kPointer"):
            return payload_val
        elif payload_type_int == _PT_INT.get("kUI64"):
            return payload_val
        elif payload_type_int == _PT_INT.get("kI64"):
            return struct.unpack(
                "<q", struct.pack("<Q", payload_val & 0xFFFFFFFFFFFFFFFF)
            )[0]
        elif payload_type_int == _PT_INT.get("kFP64"):
            return struct.unpack(
                "<d", struct.pack("<Q", payload_val & 0xFFFFFFFFFFFFFFFF)
            )[0]
        else:
            return payload_val

    def parse_payload_value(
        self, payload_val: int, payload_type
    ) -> Union[None, int, float]:
        """
        Parse a uint64 payload value based on its payload type.

        Args:
            payload_val: The raw uint64 payload value stored in marker data
            payload_type: The type of the payload (IketEvtPayloadType enum or int)

        Returns:
            The parsed value in the appropriate Python type:
            - None for kNoPayload
            - int for integer types (kI8, kUI8, kI16, kUI16, kI32, kUI32, kPointer, kUI64)
            - float for floating point types (kFP4, kFP8, kFP16, kBF16, kFP32)
        """
        pt_int = (
            payload_type if isinstance(payload_type, int) else _enum_int(payload_type)
        )
        return self._parse_payload_value_int(payload_val, pt_int)

from typing import List, Dict, Tuple, Set, Optional, Iterable, TYPE_CHECKING
from ..core import (
    IketContext,
    IketEventPos,
    IketInstrumentMethod,
    IketEventSummary,
    IketKernelInstrumentPoint,
    IketEvtPayloadType,
)

if TYPE_CHECKING:
    import smodel
    from smodel.sass import Module, Function, Instruction
    from smodel.tools.iket.resource_selection import ResourceSelection
else:
    try:
        import smodel
        from smodel.sass import Module, Function, Instruction
        from smodel.tools.iket.resource_selection import ResourceSelection
    except ImportError:
        smodel = None


from .calltrack import Calltrack


class InstrumentConfig:
    def __init__(self, meta: Dict, configs: List[Dict]):
        self.meta = meta  # metadata
        self.configs = configs  # list of function instrument config

    def to_dict(self):
        return {"meta": self.meta, "configs": self.configs}


def jsonify_iket_range_pos(r: IketEventPos):
    val = str(r).replace("IketEventPos.", "")
    val = val[1].lower() + val[2:]
    if val == "rangeStartEnd":
        val = "startEnd"
    return val


class IketModule:
    def __init__(
        self,
        image: str,
        module_id: int,
        mhash: int,
        size: int,
        functions: Set[str],
        events: Dict[int, IketEventSummary],
        iket_cubin_context: IketContext,
    ):
        self.image = image
        self.module_id = module_id
        self.hash = mhash
        self.size = size
        self.functions = functions
        self.events = events
        self.iket_cubin_context = iket_cubin_context
        self._sass_module: Optional["Module"] = None

    @property
    def sass_module(self) -> "Module":
        if self._sass_module is None:
            if smodel is None:
                raise RuntimeError("smodel is not available")
            self._sass_module = Module.create_module_from_file(
                self.image, list(self.functions)
            )
        return self._sass_module


class IketPointConfig:
    def __init__(
        self,
        instrument_method: IketInstrumentMethod,
        offset: int,
        idx: int,
        reg: int,
        scoreboard_rd: int,
        scoreboard_reqs: List[int],
    ):
        self.instrument_method = instrument_method
        self.offset = offset  # program counter
        self.idx = idx  # event id
        self.reg = reg
        self.scoreboard_rd = scoreboard_rd
        self.scoreboard_reqs = scoreboard_reqs

    def to_dict(self):
        return {
            "offset": self.offset,
            "idx": self.idx,
            "reg": self.reg,
            "scoreboardRd": self.scoreboard_rd,
            "scoreboardReqs": self.scoreboard_reqs,
            "offsetHex": f"0x{self.offset:05x}",
        }

    @property
    def scoreboard_req_mask(self):
        # convert list of reqs to bit mask store in insturment config
        mask = 0
        for req in self.scoreboard_reqs:
            mask |= 1 << req
        return mask


class IketFunctionConfig:
    def __init__(self, name: str, warp_buffer_size: int, points: List[IketPointConfig]):
        self.name = name
        self.warp_buffer_size = warp_buffer_size
        self.points = points

    def to_dict(self):
        return {
            "name": self.name,
            "warpBufferSize": self.warp_buffer_size,
            "points": [p.to_dict() for p in self.points],
        }


class IketModuleConfig:
    def __init__(self, module: IketModule, functions: Dict[str, IketFunctionConfig]):
        self.module = module
        self.functions = functions  # function name -> function config

    @property
    def hash(self):
        return self.module.hash

    @property
    def size(self):
        return self.module.size

    def to_dict(self):
        return {
            "hash": self.hash,
            "size": self.size,
            "functions": {
                name: func.to_dict() for name, func in self.functions.items()
            },
        }


class IketAppConfig:
    def __init__(self, modules: List[IketModuleConfig]):
        self.modules = modules


class SModelFunctionGetter:
    def __init__(self, module: IketModule):
        self.module = module
        self._funcs: Dict[str, "Function"] = {}

    def __getitem__(self, func_name: str) -> Optional["Function"]:
        assert isinstance(func_name, str)
        if func_name not in self._funcs:
            f = self._check_and_get_smodel_func(func_name)
            if f is None:
                return None
            self._funcs[func_name] = f
        return self._funcs[func_name]

    def _check_and_get_smodel_func(self, func_name: str) -> Optional["Function"]:
        if smodel is None:
            return None

        func = self.module.sass_module.funcs[func_name]

        return func


def process_targets(
    funcs_getter: SModelFunctionGetter,
    func_name: str,
    targets: List[IketKernelInstrumentPoint],
) -> Tuple[List[IketKernelInstrumentPoint], List[Tuple[int, List[int]]]]:
    """
    Process the instrument points of a function.
    return:
        native_targets: List[IketKernelInstrumentPoint]
        analysis_targets: List[Tuple[int, List[int]]]
    """
    # native dump targets
    native_targets: List[IketKernelInstrumentPoint] = []
    # event id -> sequence of pcs
    analysis_target: List[Tuple[int, List[int]]] = []

    for t in targets:
        if t.evt_attr.instrument_method == IketInstrumentMethod.kNativeDump:
            native_targets.append(t)
        elif t.evt_attr.instrument_method == IketInstrumentMethod.kExtendedNativeDump:
            native_targets.append(t)
        elif t.evt_attr.instrument_method == IketInstrumentMethod.kUTraceEvent:
            # UTRACEEVENT uses a single PMTRIG instruction that gets patched to UTRACEEVENT
            # Handle similarly to NativeDump - just pass through the targets
            native_targets.append(t)
        elif t.evt_attr.instrument_method == IketInstrumentMethod.kPMTrig5:
            func = funcs_getter[func_name]
            if func is None:
                raise RuntimeError(
                    "PMTrig5 instrumentation method is used in kernel, however smodel is not available in current environment. Please use NativeDump instrumentation method instead."
                )

            seq = []
            # analysis requires the exact 5 locations of targets
            for pc in range(t.offset_start, t.offset_end + 1, 16):
                if func.get_instruction_by_pc(pc).opcode.opcode == "PMTRIG":
                    seq.append(pc)

            analysis_target.append((t.evt_attr.event_id, seq))
        else:
            raise RuntimeError(
                f"Unsupported instrument method: {t.evt_attr.instrument_method}"
            )

    return native_targets, analysis_target


def module_select_resource(
    module: IketModule, max_ts_cnt_per_warp: int, calltrack: Optional[Calltrack]
):
    """
    return the iket module config with selected resources
    """
    if calltrack is not None:
        module.sass_module.update_callgraph(calltrack.records)

    funcs_getter = SModelFunctionGetter(module)
    functions_configs: Dict[str, IketFunctionConfig] = {}
    for func_name in module.functions:
        targets = module.iket_cubin_context.get_kernel_instrument_points(func_name)
        native_targets, analysis_targets = process_targets(
            funcs_getter, func_name, targets
        )

        points: List[IketPointConfig] = []
        for native_target in native_targets:
            points.append(
                IketPointConfig(
                    native_target.evt_attr.instrument_method,
                    native_target.offset_start,  # pc of sts
                    native_target.evt_attr.event_id,
                    -1,  # default value and won't be used by injection lib
                    -1,  #
                    [],  # NOTE: scoreboard reqs are reserved by injection lib
                )
            )
        if analysis_targets:
            func = funcs_getter[func_name]
            if func is None:
                raise RuntimeError(
                    "PMTrig5 instrumentation method is used in kernel, however smodel is not available in current environment. Please use NativeDump instrumentation method instead."
                )
            resource_selection = ResourceSelection(
                module.sass_module.meta, func, analysis_targets
            )
            specs = resource_selection.select_res_by_scoreboard0()
            for offset, spec in specs.items():
                assert offset == spec.cs2r_pc
                # TODO: update the iket injection lib to support both native/analysis point
                points.append(
                    IketPointConfig(
                        IketInstrumentMethod.kPMTrig5,
                        offset,
                        spec.event_id,
                        spec.reg,
                        spec.scoreboard_rd,
                        spec.scoreboard_reqs,
                    )
                )

        points.sort(key=lambda p: p.offset)
        functions_configs[func_name] = IketFunctionConfig(
            func_name, max_ts_cnt_per_warp, points
        )

    return IketModuleConfig(module, functions_configs)


def generate_config(version: str, *args, **kargs) -> InstrumentConfig:
    # by default, we use v0 config
    if version == "v0":
        return generate_config_v0(*args, **kargs)
    elif version == "v1":
        return generate_config_v1(*args, **kargs)
    else:
        raise RuntimeError(f"Invalid config version: {version}")


def generate_config_v1(configs: Dict[int, IketModuleConfig]) -> InstrumentConfig:
    meta = {"version": 1}

    modules: List[Dict] = []
    for module_config in configs.values():
        modules.append(module_config.to_dict())

    return InstrumentConfig(meta, modules)


class PointInstrumentConfigV0:
    def __init__(
        self,
        point_config: IketPointConfig,
        events_ref: Dict[int, IketEventSummary],
    ):
        self.spec = point_config
        self.event = events_ref[self.spec.idx]

    def to_dict(self):
        resources = {
            "reg": self.spec.reg,
            "pred": 7,
        }  # default value
        if self.spec.scoreboard_rd != -1:
            resources.update(
                scoreboard_rd=self.spec.scoreboard_rd,
                req_mask=self.spec.scoreboard_req_mask,
            )

        result = {
            "instrumentMethod": str(self.spec.instrument_method),
            "offset": self.spec.offset,
            "offsetHex": f"0x{self.spec.offset:05x}",
            "id": self.spec.idx,
            "name": self.event.name,
            "rangePos": jsonify_iket_range_pos(self.event.range_pos),
            "resources": resources,
        }
        return result


class FunctionInstrumentConfigV0:
    def __init__(
        self,
        name: str,
        max_ts_cnt_per_warp: int,
        instrumentations: List[PointInstrumentConfigV0],
    ):
        self.kernel = name
        self.max_ts_cnt_per_warp = max_ts_cnt_per_warp
        self.instrumentations = instrumentations  # list of point instrument config

    def to_dict(self):
        return {
            "kernel": self.kernel,
            "maxTsCntPerWarp": self.max_ts_cnt_per_warp,
            "instrumentations": [i.to_dict() for i in self.instrumentations],
        }


def generate_config_v0(
    configs: Dict[int, IketModuleConfig],
    max_ts_cnt_per_warp: int,
) -> InstrumentConfig:
    """
    params:
        configs: module id -> iket module config
        max_ts_cnt_per_warp: max timestamp count per warp
        count_only: if True, only count timestamps without storing them

    return:
        instrument config: {meta, configs [list of function instrument config]}
    """
    meta = {"version": 0}

    kernels_config: List[FunctionInstrumentConfigV0] = []
    for module_config in configs.values():
        # for each module
        for function_name, function_config in module_config.functions.items():
            # for each function
            instrumentations_points: List[PointInstrumentConfigV0] = []
            for point in function_config.points:
                # for each point
                instrumentations_points.append(
                    PointInstrumentConfigV0(point, module_config.module.events)
                )
            kernels_config.append(
                FunctionInstrumentConfigV0(
                    function_name, max_ts_cnt_per_warp, instrumentations_points
                )
            )

    return InstrumentConfig(
        meta, [k.to_dict() for k in kernels_config if k.instrumentations]
    )


# --- Auto buffer pool sizing ---
# 16-byte WarpBufferHeader (packed: u32 + u8 + u8 + u16 + u64), aligned to 8 bytes
_WARP_BUFFER_HEADER_BYTES = 16

_PAYLOAD_64BIT_TYPES = {
    IketEvtPayloadType.kUI64,
    IketEvtPayloadType.kI64,
    IketEvtPayloadType.kFP64,
    IketEvtPayloadType.kPointer,
}

_RESERVED_EVENT_IDS = {0, 31}


def _compute_cubin_max_payload_size(iket_module: IketModule) -> int:
    """Compute CUBIN-wide max payload size in bytes (0, 4, or 8).

    Mirrors C++ IketContextImpl logic: inspects all instrument points across
    all functions in the module, skipping reserved event IDs.
    """
    max_payload = 0
    for func_name in iket_module.functions:
        points = iket_module.iket_cubin_context.get_kernel_instrument_points(func_name)
        for pt in points:
            if pt.evt_attr.event_id in _RESERVED_EVENT_IDS:
                continue
            if pt.evt_attr.payload_type in _PAYLOAD_64BIT_TYPES:
                return 8  # max possible
            elif pt.evt_attr.payload_type != IketEvtPayloadType.kNoPayload:
                max_payload = max(max_payload, 4)
    return max_payload


def compute_warp_buffer_size_bytes(
    iket_module: IketModule,
    max_ts_cnt_per_warp: int,
) -> int:
    """Compute per-warp buffer size in bytes for a given module.

    Mirrors C++ IketKernelPatchRecipeImpl::getWarpBufferSizeInBytes().
    Returns 0 for UTraceEvent-only modules (no timestamp buffer needed).
    """
    methods = {evt.instrument_method for evt in iket_module.events.values()}

    # UTraceEvent uses HWPM path, no timestamp buffer
    if IketInstrumentMethod.kUTraceEvent in methods:
        return 0

    max_payload_size = _compute_cubin_max_payload_size(iket_module)

    if IketInstrumentMethod.kExtendedNativeDump in methods:
        bytes_per_event = 16 if max_payload_size > 0 else 8
    else:
        # NativeDump or PMTrig
        if max_payload_size >= 8:
            bytes_per_event = 16
        else:
            bytes_per_event = 4 + max_payload_size

    raw_size = max_ts_cnt_per_warp * bytes_per_event + _WARP_BUFFER_HEADER_BYTES
    return (raw_size + 7) & ~7


def compute_required_buffer_size(
    tracker_records_with_configs: List[
        Tuple["TrackerRecord", Dict[int, "IketModuleConfig"]]
    ],
    max_ts_cnt_per_warp: int,
    headroom_factor: float = 1.15,
) -> int:
    """Compute required context buffer pool size from tracker data.

    Sums per-launch buffer sizes across all instrumented kernel launches
    (worst-case: all launches concurrent). Returns 0 if no buffer is
    needed (UTraceEvent-only workloads or no instrumented launches).

    Args:
        tracker_records_with_configs: list of (TrackerRecord, modules_configs) pairs
        max_ts_cnt_per_warp: max timestamps per warp (from tracker)
        headroom_factor: safety multiplier (default 1.15 = 15% headroom)
    """
    # Avoid circular import
    from .tracker_record import TrackerRecord

    total_bytes = 0

    for tracker_record, modules_configs in tracker_records_with_configs:
        # Build lookup: module_id -> warp_buffer_size
        module_warp_buf_size: Dict[int, int] = {}
        for module_id, module_config in modules_configs.items():
            module_warp_buf_size[module_id] = compute_warp_buffer_size_bytes(
                module_config.module, max_ts_cnt_per_warp
            )

        # Sum over all instrumented launches
        for launch in tracker_record.iterate_kernel_launches():
            if launch.module_id not in module_warp_buf_size:
                continue
            warp_buf_size = module_warp_buf_size[launch.module_id]
            if warp_buf_size == 0:
                continue

            ctas = launch.grid_dim.x * launch.grid_dim.y * launch.grid_dim.z
            threads = launch.block_dim.x * launch.block_dim.y * launch.block_dim.z
            warps_per_cta = (threads + 31) // 32
            total_bytes += ctas * warps_per_cta * warp_buf_size

    if total_bytes == 0:
        return 0

    return int(total_bytes * headroom_factor)
